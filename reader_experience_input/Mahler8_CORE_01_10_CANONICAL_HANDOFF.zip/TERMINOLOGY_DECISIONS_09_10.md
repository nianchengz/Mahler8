# CORE 09–10｜術語決策

狀態：供後續 Final Editorial 繼承。僅記錄會影響全書的新增決定，不建立大型 glossary。

| 原詞／概念 | CORE 09–10 固定用法 | 必須保留的差別 |
|---|---|---|
| monumentality | 首次寫「monumentality（紀念碑式宏偉／巨型尺度）」；後文依句法用「宏偉」「巨大尺度」或保留原文。 | 指尺度產生的文化、審美與權威效果，不是 performer count 的同義詞；不自動褒義或貶義，也不直接證成政治意圖。 |
| public | 依功能寫「公共形式」「公共藝術作品」「公共主張」「公共經驗」。 | `public` 不自動等於 1910 實際 audience、民族或全民共識；後者需首演／接受史證據。 |
| collective | 固定「集體」；若指演出關係，優先寫「集體發聲」。 | 不與 `public` 或 `universal` 互換；多人發聲不證明所有人被代表。 |
| universal / universality | 寫「普世／普世性」，並盡量標明是「藝術主張」「權威效果」或具名詮釋。 | 不寫成作品已實現的政治包容，也不由巨大規模直接推導。 |
| performance-and-listening community | 固定「表演與聆聽共同體」。 | 與政治共同體、文化共同體、閱讀與友誼網絡、祈禱共同體分開；指演出中由身體、分工與共享注意力暫時形成的群體。 |
| genre crossing | 固定「類型越界」。 | 表示作品同時調動多種類型記憶，不表示已無類型，也不要求選出唯一名稱。 |
| symphonic Mass | 固定「交響彌撒（*symphonic Mass*）」並明標為十九世紀類型史／分析框架。 | 不因此把《馬勒第八號》客觀分類為 Mass；Mahler「我的彌撒」是 Roller 轉述的後來自我描述。 |
| Gesamtkunstwerk | 固定「總體藝術作品（*Gesamtkunstwerk*）」。 | 只在有證據的類型／文化討論中使用；不建立 Wagner 或 Reinhardt 對《第八號》的文件化影響。 |
| Mysterium / mystery | 依語境寫「神秘劇／奧祕式戲劇（*Mysterium*）」；Devutsky 的 `symphony-mystery` 寫「交響—神秘劇」。 | `mystery` 不是「尚待破解的祕密」；Devutsky 模型不等於 Mahler programme，也不與 Christian sacrament 自動等同。 |
| sacred / religious | `sacred` 依語境譯「神聖／宗教性」；`religious work` 寫「宗教作品」或「具有宗教內容的作品」。 | 不與 `liturgical`（禮儀性／用於禮儀）互換；音樂會作品可保留宗教內容而非正式禮儀。 |
| humanist | 固定「人文主義的／人文取向」並標示為分析框架。 | 不表示無宗教、反宗教或「人類自救」；不能取代 *Spiritus*、恩典與祈禱的歷史身分。 |
| metaphysical | 固定「形上的／形上計畫」。 | 指創造來源、整體、死亡、轉化等問題；不可用抽象詞抹去具體角色、歷史與權力關係。 |
| utopia / utopian impulse | `utopia` 依語境用「烏托邦」；`utopian impulse` 固定「烏托邦衝動」。 | 不等於可執行的理想社會藍圖或已完成和解；Papanikolaou／Bloch／Adorno 脈絡須分別歸屬。 |
| affirmation | 固定「肯定」。 | 先問肯定的對象；聲響肯定不等於倫理、歷史與政治矛盾皆已解決，也不等於作品必然真誠。 |
| counter-reading | 固定「反讀／反向閱讀」，依句法使用。 | 後來批評用來測試作品的盲點，不是 Mahler 的原始 programme，也不是為形式平衡而加入的假反方。 |
| later reception | 沿用「後來接受／接受史」。 | Barham／Fassbinder 材料只證明後來再語境化；不得回投至 1906 genesis 或 1910 audience。 |
| temporary enactment | CORE 10 的書內綜合採「暫時成形／暫時實行」。 | 指藝術能在演出時間內使可能世界可被共同經驗；不是說作品虛假，也不表示歷史和解已完成。 |

## 繼承確認

- 沿用 CORE 01–08 的 *Streben*、救贖／得救、恩典、*Liebe*、*caritas*、*Eros*、*Spiritus*／*Geist*、代求、照明、轉化、上升與永恆女性等決定。
- 沿用 `finished-work integration`＝「完成作品中的整合」、`initial compositional genesis`＝「最初形成史／初始作曲形成」的區分。
- `interpretation`、`context`、`documented connection`、`reception` 仍保持不同證據層級，不因終章需要收束而加強句法。
