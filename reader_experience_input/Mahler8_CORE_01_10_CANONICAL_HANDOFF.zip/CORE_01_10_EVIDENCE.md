==================================================
ORIGINAL FILE: CORE_01_EVIDENCE.md
==================================================

# CORE 01｜內部證據紀錄

本檔供編輯查核。頁碼以來源印刷頁為準；Batstone 同列本地 PDF 頁碼。Klautke 是研究述評，取自其受評著作的社會史細節維持 CONTEXT，不提升為未經中介的 primary evidence。

| Claim | Source ID | Author / title | Exact page / section / reliable location | Evidence type | Confidence | Qualification / limitation |
|---|---|---|---|---|---|---|
| Vienna 1900 不宜概括為單一 Zeitgeist，而須同時處理政治、文化與城市力量。 | SRC-009；SRC-010 | E. Papanikolaou, “Aestheticism and the City”；E. Klautke, “Anarchy and Noise” | Papanikolaou pp. 239–248；Klautke pp. 161–164 | CONTEXT | HIGH | 兩文支持多重力量並存，不證明每位居民的私人信念。 |
| 1857 年後拆除防禦工事並興建 Ringstraße，城市擴張與帝國／自由主義文化秩序相連。 | SRC-009 | Papanikolaou, “Aestheticism and the City” | pp. 239–241 | CONTEXT | HIGH | 學術綜合，非工程檔案。 |
| Ringstraße 的國會、市政廳、大學分別以希臘、哥德、文藝復興式樣賦予制度象徵。 | SRC-009 | Papanikolaou, “Aestheticism and the City” | p. 241 | FACT | HIGH | 「公共辭典」是正文教學比喻。 |
| 大道既宣告進步，也可維持城市中心的社會支配與空間分隔。 | SRC-009；SRC-010 | Papanikolaou；Klautke | Papanikolaou pp. 239–243；Klautke pp. 161–163 | INTERPRETATION | MEDIUM | 不宣稱 Ringstraße 只有壓迫功能。 |
| 十九世紀末大眾政治使自由主義不能再自居為全城市的自然代表。 | SRC-009；SRC-010 | Papanikolaou；Klautke | Papanikolaou pp. 243–246；Klautke pp. 161–164 | CONTEXT | MEDIUM | 未在本章建立完整選舉權史。 |
| 1897 年 Lueger 獲任市長、Secession 成立、Mahler 進入 Hofoper。 | SRC-009；SRC-012 | Papanikolaou；C. Niekerk, “Introduction” | Papanikolaou pp. 245–247；Niekerk p. 17 | FACT | HIGH | 三事同年可核；正文不主張互為因果。 |
| Lueger 領導 Christian Social Party，曾以公開反猶平台動員，1897 年終獲任命。 | SRC-012 | Niekerk, “Introduction” | p. 17 | FACT | HIGH | 只採導論明載的基本政治事實。 |
| Pernerstorfer 早期把 German nationalism 與 socialism 視為相容，後因泛德運動激進種族反猶主義而與 Schönerer 分道。 | SRC-001 | L. Batstone, *Mahler, Nietzsche and the Pernerstorfer Circle* | pp. 32–34、235–236／PDF pp. 43–45、246–247 | FACT | MEDIUM | 個案只說明政治標籤內部分歧。 |
| 1883 年地理學者以十二個民族、五種教派描述 Habsburg monarchy。 | SRC-001 | Batstone | p. 233／PDF p. 244 | CONTEXT | MEDIUM | Batstone 轉引 Umlauf；不作精密人口統計。 |
| Habsburg identity 可同時包含奧地利政治忠誠、德／捷／波文化歸屬與猶太族群身分。 | SRC-001 | Batstone | pp. 233–235／PDF pp. 244–246 | CONTEXT | MEDIUM | 分析模型，不是每人的固定配方。 |
| Mahler 與圈內友人來自 Bohemia、Galicia、Moravia、Hungary 等帝國區域，具有重疊文化背景。 | SRC-001 | Batstone | pp. 228–236／PDF pp. 239–247 | FACT | MEDIUM | 不把個別身分經驗寫成相同。 |
| 1867 年改革有助 Jewish emancipation；法律解放不等於接納，assimilation／conversion 也未消除種族化反猶。 | SRC-009；SRC-012 | Papanikolaou；Niekerk | Papanikolaou p. 239 n.1、245–247；Niekerk pp. 14–20 | CONTEXT | HIGH | 未建立完整 Habsburg Jewish legal history。 |
| Mahler 就任 Hofoper 前改宗可置於職業與反猶壓力中理解，不能據此斷定私人信仰。 | SRC-009；SRC-012 | Papanikolaou；Niekerk | Papanikolaou pp. 246–247；Niekerk pp. 17–20 | CONTEXT | HIGH | 外在條件不等於唯一心理動機。 |
| Pernerstorfer Circle 是 1870 年代 Vienna 大學生的非正式、邊界流動網絡。 | SRC-001 | Batstone | pp. 24–25／PDF pp. 35–36 | FACT | HIGH | 不是有正式統一綱領的學派。 |
| 圈內接觸 Wagner、Nietzsche、Schopenhauer、Goethe 等多種文化權威。 | SRC-001 | Batstone | pp. 27–29／PDF pp. 38–40 | FACT | HIGH | 接觸不等於對《第八號》的直接影響。 |
| Lipiner 於 1878 年以 Nietzsche 思想討論宗教思想更新；Mahler 約同年進入圈子。 | SRC-001 | Batstone | p. 28／PDF p. 39 | FACT | HIGH | 只證明青年網絡的討論並置。 |
| 圈子後來分向政治行動與美學／宗教更新，私人及思想聯繫未完全切斷。 | SRC-001 | Batstone | pp. 29–34／PDF pp. 40–45 | FACT | MEDIUM | 不把分化寫成兩個封閉陣營。 |
| 只談高文化中心會漏掉移民、勞工、外圍區域與日常城市生活。 | SRC-010 | Klautke | pp. 161–164 | CONTEXT | MEDIUM | 內容部分經研究述評中介。 |
| 反噪音運動同時要求路面／交通改善與限制鞭聲、小販、街頭音樂等行為。 | SRC-010 | Klautke | pp. 164–168 | CONTEXT | HIGH | 技術改善與階級規範並存，不化約成單一陰謀。 |
| modernization、modernity、modernism 應分別指制度生活變化、歷史經驗與藝術回應。 | SRC-009；SRC-010；SRC-012 | Papanikolaou；Klautke；Niekerk | Papanikolaou pp. 239–248；Klautke pp. 161–168；Niekerk pp. 1–6 | INTERPRETATION | MEDIUM | 教學性區分，不是來源提供的單一定義。 |
| 城市背景能說明文本為何可用，不能證明它直接造成《第八號》。 | SRC-001；SRC-006；SRC-009；SRC-010；SRC-012 | Batstone；Papanikolaou 2017／2002；Klautke；Niekerk | Batstone pp. 24–34、228–236；Papanikolaou 2017 p. 186；其餘同上 | CONTEXT | HIGH | Papanikolaou 2017 明言起初想到 Faust 缺乏 concrete evidence。 |

## 未解但不阻擋成稿的限制

- 缺完整 Catholic institutional／secularization／science culture 史，本章只否定「現代化使宗教消失」的線性敘述。
- Ringstraße 與 mass politics 仍仰賴學術綜合；Schorske 與主要修正派 Vienna 史全文未在目前 SLIM 來源中重現。
- Batstone 的音樂影響論主要處理前四首交響曲，故不把 Pernerstorfer 圈、Wagner、Nietzsche 或 Lipiner 寫成《第八號》直接成因。

==================================================
ORIGINAL FILE: CORE_02_EVIDENCE.md
==================================================

# CORE 02｜內部證據紀錄

本檔供編輯查核。Mullan 與 West 是十九世紀 Faust 音樂接受史的學術／教育性來源；它們可支持作品、選段與改編方式，不自動建立 Mahler 的影響鏈。

| Claim | Source ID | Author / title | Exact page / section / reliable location | Evidence type | Confidence | Qualification / limitation |
|---|---|---|---|---|---|---|
| Goethe／Faust 在十九世紀成為可被崇敬、爭辯、改編的文化權威。 | SRC-005；SRC-007 | C. Mullan, *Poetry Into Song*；J. West, *Goethe's Faust and Nineteenth-Century Music* | Mullan chs. 1–2, pp. 1–99；West Introduction, pp. 1–9 | CONTEXT | HIGH | 文化可見度與接受廣度不證明每位作曲家的直接依賴。 |
| Goethe 同時具有作家、劇作家、Weimar 宮廷任職者、自然研究者與劇場實務者等公共位置。 | SRC-005；SRC-007 | Mullan；West | Mullan pp. 17–34、ch. 3 opening；West Introduction, pp. 1–2 | CONTEXT | HIGH | 只用來說明文化位置，不在本章評價其各領域成就。 |
| Goethe 的抒情詩、音樂劇場興趣與作曲家往來，使其文字長期進入音樂實踐。 | SRC-005；SRC-007 | Mullan；West | Mullan chs. 2–3, esp. pp. 35–46、103–110；West pp. 1–3 | CONTEXT | MEDIUM | West 對 Goethe 音樂判斷力的討論有爭議；正文只採可核的實踐範圍。 |
| Faust 傳說在 Goethe 前已有博士、魔術／禁忌知識、惡魔契約與懲罰的組合。 | SRC-005；SRC-004 | Mullan；Goethe/Latham, historical introduction | Mullan pp. 1–14；Latham Introduction, “The Faust-Legend” | CONTEXT | HIGH | Latham 是早期二十世紀綜合；正文只採最低傳統輪廓。 |
| 1587 年德語 Faustbook 以受罰結局鞏固警世傳統。 | SRC-005；SRC-004 | Mullan；Latham | Mullan pp. 5–9；Latham Introduction, pp. xiii–xxvii | FACT | MEDIUM | 未取得 1587 原書的現代批判版。 |
| Marlowe 將 Faust 素材發展為重要舞台悲劇。 | SRC-005；SRC-004 | Mullan；Latham | Mullan pp. 10–13；Latham Introduction, “Marlowe's Faustus” | CONTEXT | HIGH | 不進入版本與年代爭議。 |
| Lessing 的未完成計畫使求知／追求與可能得救建立新關係。 | SRC-005 | Mullan | pp. 13–17 | CONTEXT | MEDIUM | 作品未完成；只說明接受史轉向，不稱其為 Goethe 單一來源。 |
| Goethe 數十年工作於 Faust；Part I 1808、Part II 1832 死後完整出版。 | SRC-005；SRC-004 | Mullan；Goethe/Latham | Mullan pp. 17–34；Latham Introduction, chronology sections | FACT | HIGH | 基本出版史；不在本章重建全部手稿階段。 |
| Goethe 的 Faust 由多學科知識仍不滿足出發，將人物改寫為知識與生活危機的主體。 | SRC-004；SRC-018 | Goethe/Latham；I. Gillo, “Die verkehrte Bekehrung” | *Faust I*, “Night,” printed pp. 25–42；Gillo pp. 464–466 | FACT | HIGH | 「現代主體」是後來分析語彙。 |
| 與 Mephistopheles 的核心條件是 Faust 對滿足瞬間說 `Verweile doch`，不是固定二十四年。 | SRC-004 | Goethe/Latham | *Faust I*, “Study,” printed pp. 76–80／PDF pp. 140–144 | FACT | HIGH | 仍有血契與彼世服務，故不否認「靈魂買賣」的部分真實。 |
| Goethe 將 Gretchen 悲劇置於 Faust 敘事中心，使追求的性別／社會後果可見。 | SRC-004；SRC-005；SRC-019 | Goethe/Latham；Mullan；G. Trop, “Goethe's Faust…” | *Faust I*, Gretchen scenes, esp. printed pp. 130–222；Mullan pp. 24–30；Trop pp. 399–404 | CONTEXT | HIGH | 社會權力分析是文本與研究的綜合，不是 Goethe 明示命題。 |
| Faust II 把人物活動擴至宮廷、神話、戰爭與土地工程。 | SRC-003；SRC-004；SRC-005 | Goethe, *Faust II*；Latham；Mullan | Goethe Acts I–V；Latham printed pp. 1–342；Mullan pp. 30–34 | FACT | HIGH | 本章只說尺度擴張，不摘要所有場景。 |
| Logos 依次改譯為 Wort／Sinn／Kraft／Tat；Gillo 稱之為「反向皈依」。 | SRC-004；SRC-018 | Goethe/Latham；Gillo | *Faust I*, “Study,” printed pp. 59–60；Gillo pp. 466–477 | INTERPRETATION | HIGH | 字詞次序為 FACT；「反向皈依／自主行動原則」為具名詮釋。 |
| Faust 將知識、宗教權威、自主行動與責任衝突集中為可反覆改寫的現代個人問題。 | SRC-018；SRC-019；SRC-020 | Gillo；Trop；S. Hajduk, “Goethes Gnostiker” | Gillo pp. 476–477；Trop pp. 388–406；Hajduk pp. 89–109 | INTERPRETATION | MEDIUM | 三種後來讀法並不一致；不合成 Goethe 教義。 |
| Faust 文本充滿歌曲、祈禱、合唱和片段式場景，容許音樂家以選段塑造不同人物中心。 | SRC-004；SRC-005 | Goethe/Latham；Mullan | *Faust I–II* scene texts；Mullan ch. 2, pp. 35–99 | CONTEXT | HIGH | 「容許」是接受史推論，不主張文本必然導向特定體裁。 |
| Schubert〈Gretchen am Spinnrade〉以鋼琴紡車音型表現 Gretchen 的內在時間，在吻的回憶處停止後重啟。 | SRC-005 | Mullan | pp. 46–51, esp. pp. 49–50 | DOCUMENTED CONNECTION | HIGH | 音型／停止可核；心理意義經 Mullan 及其引用研究解讀。 |
| Berlioz 由 *Huit scènes* 擴成 1846 *La Damnation de Faust*，自由調整材料並使 Faust 受罰。 | SRC-005；SRC-007 | Mullan；West | Mullan pp. 84–87；West “Berlioz,” pp. 16–23 | FACT | HIGH | 支持改編差異，不把 Berlioz 寫成 Mahler 因果來源。 |
| Schumann 1844–53 *Szenen aus Goethes Faust* 先設定《神祕合唱》，後納入 Part I 場景，主要取材 Part II。 | SRC-005；SRC-007 | Mullan；West | Mullan pp. 60–62；West “Schumann,” pp. 24–30 | FACT | HIGH | 不沿用 West 將 Faust 誤認為 Doctor Marianus 的錯誤。 |
| Liszt《浮士德交響曲》以三個人物樂章構成；Mephistopheles 扭曲 Faust 主題，終曲後加《神祕合唱》。 | SRC-005；SRC-007；SRC-006 | Mullan；West；Papanikolaou | Mullan pp. 87–89；West “Liszt,” pp. 38–45；Papanikolaou p. 183 n.1 | DOCUMENTED CONNECTION | HIGH | 人物／主題分析不等於敘事全劇。 |
| 十九世紀音樂接受展示多個不同 Faust 問題，而非單一作曲家清單。 | SRC-005；SRC-007 | Mullan；West | Mullan ch. 2；West essays pp. 10–48 | INTERPRETATION | HIGH | 教學綜合，例子刻意限量。 |
| Mahler 選擇 Schlußszene 可置於長期 musical availability 中，但 availability 不等於 influence。 | SRC-005；SRC-006；SRC-007 | Mullan；Papanikolaou；West | Mullan pp. 78–84；Papanikolaou pp. 183–187；West pp. 1–9、74 | CONTEXT | HIGH | Papanikolaou p. 186 明言創作起點缺具體 Faust 證據。 |

## 未解但不阻擋成稿的限制

- Mullan Volume 2 不在目前來源中；本章未引用需靠其譜例附錄才能成立的細節。
- 缺 Jane Brown、Bodley 全書與完整十九世紀接受史；Goethe 的文化地位主要由 Mullan、West 的綜合與作品接受範圍支撐。
- 具體音樂例只用來教「選段如何製造不同 Faust」，不主張 Schubert、Berlioz、Schumann 或 Liszt 直接影響 Mahler。
==================================================
ORIGINAL FILE: CORE_03_EVIDENCE.md
==================================================

# CORE 03｜內部證據紀錄

本檔供編輯查核。Goethe German text 的 local lines 僅為檢索位置，不是批判版行號；Latham 英譯用印刷頁與場景定位，翻譯只供理解。

| Claim | Source ID | Author / title | Exact page / section / reliable location | Evidence type | Confidence | Qualification / limitation |
|---|---|---|---|---|---|---|
| Faust 已研習哲學、法律、醫學、神學，仍認為自己不知道值得知道的事。 | SRC-004 | Goethe/Latham, *Faust I* | “Night,” printed pp. 25–26／PDF pp. 89–90 | FACT | HIGH | 依戲劇自述，不評估其客觀學術能力。 |
| 他轉向魔法、求見使世界結合的深層力量，召喚地靈後受挫，準備自殺又被復活節鐘聲打斷。 | SRC-004；SRC-018 | Goethe/Latham；Gillo | “Night,” printed pp. 25–42；Gillo pp. 464–466 | FACT | HIGH | 鐘聲喚起記憶，不直接等同完成皈依。 |
| Prologue in Heaven 先有 Lord 與 Mephistopheles 對 Faust 的賭約／試探。 | SRC-004；SRC-005 | Goethe/Latham；Mullan | “Prologue in Heaven,” printed pp. 19–24；Mullan pp. 23–24 | FACT | HIGH | 與 Faust 後來親自簽的協議分開。 |
| Faust／Mephistopheles 協議包括此世服務、彼世回報與血簽。 | SRC-004 | Goethe/Latham | “Study,” printed pp. 76–80／PDF pp. 140–144 | FACT | HIGH | 支持「靈魂買賣」的部分輪廓。 |
| Faust 把條件改為被享樂欺騙至滿足，並對瞬間說 `Verweile doch`。 | SRC-004；SRC-003 | Goethe/Latham；Goethe German | *Faust I*, “Study,” printed pp. 77–80；*Faust II*, Act V, local lines 9381–9401 | FACT | HIGH | Part II 重現字句時涉及未實現未來與條件式。 |
| `selling his soul` 是過度簡化，因核心勝負取決於滿足條件而非固定期限。 | SRC-004；SRC-005 | Goethe/Latham；Mullan | 同上；Mullan pp. 24–25 | INTERPRETATION | HIGH | 不否認惡魔、血契與彼世服務。 |
| Mephistopheles 自稱「永遠否定的精神」及「想作惡而造成善之力量的一部分」。 | SRC-004 | Goethe/Latham | *Faust I*, first “Study,” printed pp. 64–65 | FACT | HIGH | 自我描述不等於全劇對其作用的最後裁判。 |
| Logos 被依次寫成 Word／Thought(Mind)／Might／Deed；Gillo 讀成反向皈依。 | SRC-004；SRC-018 | Goethe/Latham；Gillo | “Study,” printed pp. 59–60；Gillo pp. 466–477 | INTERPRETATION | HIGH | 字詞次序為 FACT；主體性含義為 Gillo 詮釋。 |
| Faust／Mephistopheles 對 Gretchen 的追求涉及首飾、居間、藥劑與幽會安排。 | SRC-004 | Goethe/Latham | *Faust I*, “Street” through “Martha's Garden,” printed pp. 123–166 | FACT | HIGH | 不把 Gretchen 寫成無行動能力；此列只追蹤二人手段。 |
| Gretchen 的母親因藥劑死亡，Valentin 在衝突中身亡；Gretchen 懷孕、殺嬰、入獄待決。 | SRC-004；SRC-005 | Goethe/Latham；Mullan | *Faust I*, “Cathedral,” “Dreary Day,” “Dungeon,” printed pp. 180–222；Mullan pp. 24–30 | FACT | HIGH | 事件有角色陳述與場景呈現；法律／社會脈絡只作最低概括。 |
| 牢獄中 Gretchen 拒絕逃亡，把自己交付上帝；Mephistopheles 說被判罪，上方聲音回「得救」。 | SRC-004 | Goethe/Latham | “Dungeon,” printed pp. 212–222／PDF pp. 276–286 | FACT | HIGH | 她的判斷與得救和 Faust 當下命運分開。 |
| Faust II 由市民悲劇轉入宮廷、古典神話、戰爭與工程等更大尺度。 | SRC-003；SRC-004 | Goethe German；Goethe/Latham | *Faust II*, Acts I–V／printed pp. 1–342 | FACT | HIGH | 教學只抓尺度，不概述每場。 |
| 皇帝宮廷陷入國庫、債務與欠餉危機後，以領土下尚未開採的財寶擔保紙幣；帳目逐一結清、軍餉獲得預付，紙幣進入兌換與消費流通。 | SRC-003；SRC-004 | Goethe German；Goethe/Latham | *Faust II*, Act I, “Imperial Palace—Council Chamber” and “Pleasure Garden”；German local lines 333–625、1838–1940 | FACT | HIGH | 正文只用可見的戲劇效果建立制度尺度；不由此建立完整貨幣理論或斷言長期成敗。 |
| Faust 與古典神話人物 Helena 結合並生下 Euphorion；Euphorion 渴望向高處與遠方躍進、不顧父母勸阻而展翼墜落，Helena 隨後離去，結合未成為永久完成。 | SRC-003；SRC-004；SRC-022 | Goethe German；Latham；C. Niekerk, “Sexual Imagery…” | *Faust II*, Act III, Euphorion sequence；German local lines 6748–7200；Niekerk local paras. 70–123 | FACT | HIGH | 「古典／浪漫綜合」是可爭論的後來解釋，不作情節事實；正文只據戲劇行動說明 Faust 得到理想之美後仍未抵達可停留的終點。 |
| 晚年 Faust 經營築堤、填海與殖地工程。 | SRC-003；SRC-004 | Goethe German；Goethe/Latham | *Faust II*, Act V, “Open Country,” “Palace,” local lines approx. 8930–9420 | FACT | HIGH | 不把工程願景預先判為純進步或純邪惡。 |
| Faust 要求移走 Philemon／Baucis，Mephistopheles 的暴力執行導致死亡與焚毀。 | SRC-003；SRC-004；SRC-019 | Goethe German；Latham；Trop | *Faust II*, Act V, “Open Country” and “Palace,” local lines approx. 8930–9180；Trop pp. 395–399 | FACT | HIGH | Mephistopheles 執行不取消 Faust 啟動命令的責任。 |
| Care 使 Faust 失明；他把掘墓聲誤認為工程聲。 | SRC-003；SRC-004 | Goethe German；Goethe/Latham | Act V, “Midnight” and “Great Outer Court,” local lines approx. 9220–9365／printed pp. 317–321 | FACT | HIGH | 戲劇反諷可核。 |
| Faust 以條件式想像未來自由人民／自由土地，說對那一刻可以喊 `Verweile doch`，隨後死亡。 | SRC-003；SRC-004 | Goethe German；Goethe/Latham | Act V, local lines 9367–9414／printed pp. 321–323 | FACT | HIGH | 願景未實現且當下是墓穴；是否算輸賭約故意留有解釋空間。 |
| 天使令 Mephistopheles 失手，山谷終場以多層角色處理 Faust 死後狀態。 | SRC-003；SRC-004 | Goethe German；Goethe/Latham | “Entombment” to “Mountain Gorges,” local lines 9415–10033／printed pp. 323–342 | FACT | HIGH | 戲劇順序不等於單一神學系統。 |
| Gretchen 以 `Una Poenitentium` 重現，請求教導尚被新日照得目眩的 Faust；Mater Gloriosa 准其上升。 | SRC-003；SRC-004 | Goethe German；Goethe/Latham | local lines 9976–10013／printed pp. 341–342 | FACT | HIGH | Gretchen 不等於 Mater Gloriosa，也不是 Doctor Marianus。 |
| Gretchen 的結構作用同時包含揭露後果、牢獄判斷、終場代求與教導。 | SRC-003；SRC-004；SRC-019 | Goethe；Latham；Trop | *Faust I* “Dungeon”；*Faust II* final scene；Trop pp. 399–404 | INTERPRETATION | HIGH | 不以她的功能抹去其主體與受害史。 |

## 未解但不阻擋成稿的限制

- 目前無現代德文批判版；German Gutenberg 與 Latham 歷史英譯足以核對情節與措辭，不足以處理文本異文。
- CORE 03 不裁決 `Verweile doch` 是否在技術上使 Faust 輸掉賭約，也不完整處理得救機制；該問題移交 CORE 04。
- 宮廷紙幣、Helena／Euphorion 與土地工程只為建立尺度變化，不取代各幕專章式分析。
==================================================
ORIGINAL FILE: CORE_04_EVIDENCE.md
==================================================

# CORE 04｜內部證據紀錄

本檔供編輯查核。核心做法是把 Goethe 劇本文字、Eckermann 轉述、具名學者詮釋與本書教學綜合分開。

| Claim | Source ID | Author / title | Exact page / section / reliable location | Evidence type | Confidence | Qualification / limitation |
|---|---|---|---|---|---|---|
| Faust 對 Gretchen 與 Philemon／Baucis 的後果負有不可全推給 Mephistopheles 的責任。 | SRC-003；SRC-004；SRC-019 | Goethe；Latham；Trop | *Faust I* Gretchen tragedy；*Faust II* Act V；Trop pp. 395–404 | INTERPRETATION | HIGH | 文本提供行動鏈；責任分配是倫理判斷，不等於法律裁判。 |
| 得救指 Faust 靈魂未被 Mephistopheles 占有而被帶入另一秩序。 | SRC-003；SRC-004 | Goethe, *Faust II*；Latham | “Entombment”／“Mountain Gorges,” local lines 9415–9850；printed pp. 323–338 | FACT | HIGH | 不因此宣告他從未有罪。 |
| Faust 得救後仍有 `Erdenrest`、須逐步完成，顯示被接引不等於完成。 | SRC-003；SRC-004 | Goethe；Latham | final scene, local lines approx. 9842–9898／printed pp. 337–338 | FACT | HIGH | `Erdenrest` 的形上意義不在本章窮盡。 |
| `Wer immer strebend sich bemüht, Den können wir erlösen` 是持續追求者「我們能夠拯救」。 | SRC-003；SRC-004 | Goethe；Latham | final scene, local lines 9823–9827／printed p. 337 | FACT | HIGH | 中文保留 ongoing aspect 與 `können wir`，不譯成必然自救。 |
| 該句緊接 `Liebe von oben` 參與其身的條件／作用。 | SRC-003；SRC-004 | Goethe；Latham | local lines 9827–9831／printed p. 337 | FACT | HIGH | `Liebe` 不自動等同 `Gnade`、基督宗教的愛／仁愛（`caritas`）或愛欲（`Eros`）。 |
| 名句須放在天使集體救援與後續多角色終場內理解。 | SRC-003；SRC-004 | Goethe；Latham | “Entombment” through final Chorus, local lines 9600–10033 | CONTEXT | HIGH | 單句文法不足以構成完整救贖論。 |
| Streben 是活動形式，不保證其對象、手段與後果合乎道德。 | SRC-003；SRC-019 | Goethe；Trop | Act V, local lines 8930–9414；Trop pp. 392–404 | INTERPRETATION | HIGH | Trop 是具名 Naturphilosophie 讀法；正文把其倫理提醒轉成教學區分。 |
| Faust 的自由共同體願景與強制、土地暴力及墓穴誤認並存。 | SRC-003；SRC-004；SRC-019 | Goethe；Latham；Trop | Act V, local lines approx. 8930–9414；Trop pp. 395–399 | CONTEXT | HIGH | 不因此否定願景內容的全部價值。 |
| Goethe 在劇本文字用 `Liebe von oben`，不是 `Gnade`。 | SRC-003 | Goethe, *Faust II* | local lines 9827–9831 | FACT | HIGH | 術語差異必須保存。 |
| Eckermann 記錄 Goethe 以 higher/purer activity、eternal love from above 與 divine grace 說明 Faust 得救。 | SRC-006 | E. Papanikolaou, “Linking Christian and Faustian Utopias” | p. 185，轉引 1831-06-06 Eckermann conversation | DOCUMENTED CONNECTION | MEDIUM | 二手引述的報導談話，不是 Goethe 自撰系統神學。 |
| 恩典是自我之外的協助，不能視為努力後取得的報酬。 | SRC-006；SRC-023 | Papanikolaou；D. Bauer, “Veni Creator Spiritus” | Papanikolaou p. 185；Bauer pp. 80、83 | CONTEXT | HIGH | 只作本章必要區分，不建立完整 grace doctrine。 |
| Christian imagery 可作哲學／戲劇象徵運作，不能直接等同嚴格教義系統。 | SRC-006 | Papanikolaou | pp. 184–185、193–195 | INTERPRETATION | HIGH | 這是 Papanikolaou 的方法性提醒。 |
| Gretchen 以 `Una Poenitentium, sonst Gretchen genannt` 出場並向 Mater Gloriosa 為 Faust 請求。 | SRC-003；SRC-004 | Goethe；Latham | local lines 9976–10013／printed pp. 341–342 | FACT | HIGH | 代求不等於單靠戀愛情感取消責任。 |
| Gretchen 同時是承認自身罪責的悔罪者與 Faust 行動的受害者。 | SRC-004；SRC-019 | Goethe/Latham；Trop | *Faust I* “Cathedral”／“Dungeon”；Trop pp. 399–404 | CONTEXT | HIGH | 不把受害與能動性互相取消。 |
| Mater Gloriosa 回應 Gretchen 並允許她上升，Faust 感知她即跟隨。 | SRC-003；SRC-004 | Goethe；Latham | local lines 10008–10013／printed p. 342 | FACT | HIGH | 她不是 Gretchen、一般母性或 Eternal Feminine 的簡單同義詞。 |
| Gretchen 說 Faust 幾乎尚未察覺新生命、仍被新日照得目眩，並請求教導。 | SRC-003；SRC-004 | Goethe；Latham | local lines 9994–10009／printed pp. 341–342 | FACT | HIGH | 支持 continuing transformation，不等於已完成無罪。 |
| Teaching、ascent、transformation 是終場中相連但不同的過程。 | SRC-003；SRC-006；SRC-019 | Goethe；Papanikolaou；Trop | Goethe final scene；Papanikolaou pp. 189–193；Trop pp. 399–406 | INTERPRETATION | HIGH | 教學性區分，不主張固定教義次序。 |
| `Das Ewig-Weibliche zieht uns hinan` 表示牽引向上，但不能化約為女人、性愛、母性或單一神學實體。 | SRC-003；SRC-019；SRC-022 | Goethe；Trop；Niekerk | local lines 10025–10033；Trop pp. 399–406；Niekerk local paras. 124–154 | INTERPRETATION | HIGH | 更完整概念史屬 CORE 05；本章只防止過度化約。 |
| Gillo、Trop、Hajduk 分別提供現代主體、Naturphilosophie、Gnostic／nihilist 的自限式讀法。 | SRC-018；SRC-019；SRC-020 | Gillo；Trop；Hajduk | Gillo pp. 464–477；Trop pp. 388–406；Hajduk pp. 89–109 | INTERPRETATION | HIGH | 三者不是共識；Hajduk 明稱 heuristic、非 influence proof。 |
| 終場把人的活動、外來幫助、代求、授權、教導與轉化並置，故救贖既非單純功績也非抹除倫理。 | SRC-003；SRC-006；SRC-019 | Goethe；Papanikolaou；Trop | Goethe local lines 9823–10033；Papanikolaou pp. 184–193；Trop pp. 395–406 | INTERPRETATION | MEDIUM | 本書綜合，不是 Mahler 或 Goethe 的單句綱領。 |

## 未解但不阻擋成稿的限制

- 缺 Eckermann 原始／批判版，本章透過 Papanikolaou 的精確引文使用該談話，信心維持 MEDIUM。
- Goethe 是否可納入特定 Lutheran、Catholic、Gnostic 或 Naturphilosophie 救贖系統，現有研究沒有單一答案，本章不強行裁決。
- `Das Ewig-Weibliche` 的性別、象徵與接受史需由 CORE 05 深入；CORE 04 只確保它不被當作萬用答案。

==================================================
ORIGINAL FILE: CORE_05_EVIDENCE.md
==================================================

# CORE 05｜內部證據紀錄

本檔僅供編輯查核，不供公開刊載。Goethe 行號是本地 Project Gutenberg 檔案的 retrieval lines，不是批判版行號；Latham 只作歷史英譯對照。Papanikolaou 與 Bauer 的頁碼為印刷頁；SRC-022 無正式出版頁碼，以本地 DOCX 段落／章節定位。

| Claim | Source ID | Author / title | Exact page / section / reliable local location | Evidence type | Confidence | Qualification / limitation |
|---|---|---|---|---|---|---|
| `Das Ewig-Weibliche / Zieht uns hinan` 是神秘合唱最後兩行，前六行依次提到消逝者、譬喻、未能達成者與不可描述者。 | SRC-003；SRC-004 | Goethe, *Faust II*；Latham trans. | German local lines 10025–10033；Latham printed pp. 341–342 / PDF pp. 641–642 | FACT | HIGH | 德文轉錄非批判版；英譯不能固定中文譯義。 |
| `das` 為中性冠詞，`Ewig-Weibliche` 是名詞化抽象表達；原句不是複數「所有女性」，也未點名角色。 | SRC-003 | Goethe, *Faust II* | local lines 10025–10033 | FACT | HIGH | 語法可核，但抽象詞的完整哲學意義仍須詮釋。 |
| `zieht` 表示牽引／吸引，受詞是未標性別的 `uns`。 | SRC-003；SRC-019 | Goethe；Trop, “Goethe’s Faust and the Absolute of Naturphilosophie” | Goethe lines 10032–10033；Trop pp. 397–399 | CONTEXT | HIGH | 將 attraction 發展為宇宙論是 Trop 的具名框架。 |
| Gretchen 以 `Una Poenitentium, sonst Gretchen genannt` 重現。 | SRC-003 | Goethe, *Faust II* | local lines 9980–9987、9999–10009 | FACT | HIGH | 角色標題可證身分與發言次序，不單獨裁定其完整神學地位。 |
| Gretchen 說 Faust 尚未完全知覺新生命、被新日照得目眩，並請求准許教導他。 | SRC-003；SRC-006 | Goethe；Papanikolaou | Goethe lines 9999–10009；Papanikolaou pp. 189–192 | FACT | HIGH | Papanikolaou 的音樂意義屬分析；戲劇行動由原典支持。 |
| Mater Gloriosa 另有兩行發言，准 Gretchen 升往更高領域，並說 Faust 感知她後會跟隨。 | SRC-003 | Goethe, *Faust II* | local lines 10011–10013 | FACT | HIGH | 證明角色與功能分立；不等同完整 Marian doctrine。 |
| Doctor Marianus 是獨立發言角色，不是 Faust 的新名稱。 | SRC-003；SRC-004 | Goethe；Latham trans. | German lines 9888–9931、10015–10023；Latham printed pp. 338–341 | FACT | HIGH | 角色標題與發言次序直接支持。 |
| Doctor Marianus 對 Mater Gloriosa 使用童貞女、母親、女王、女神等混合稱謂。 | SRC-003 | Goethe, *Faust II* | local lines 9909–9912、10020–10023 | FACT | HIGH | 基督宗教與神話語彙並置；不可據此裁定 Goethe 的正式神學。 |
| Gretchen、Mater Gloriosa、Doctor Marianus 與神秘合唱分別承擔代求／教導、准允上升、祈禱／指向及抽象收束。 | SRC-003；SRC-006 | Goethe；Papanikolaou | Goethe lines 9980–10033；Papanikolaou pp. 191–193 | INTERPRETATION | HIGH | 是依角色次序作的教學性功能區分，不宣稱唯一戲劇學分析。 |
| Niekerk 以 Goethe 的 symbol 概念主張 `Das Ewig-Weibliche` 的內容開放且不能由單一定義耗盡。 | SRC-022 | Niekerk, “Sexual Imagery in Goethe’s Faust II” | section on symbol/public sphere/final scene；local extracted paras. 124–154 | INTERPRETATION | MEDIUM | 後來的 gender／symbol 閱讀；本地未驗證正式 venue 與年份。 |
| Niekerk 認為終場賦予 feminine principle 強大象徵位置，但不等於全劇已實現性別平等或取消男性權力。 | SRC-022 | Niekerk | 同上，尤自 “Women unquestionably...” 至結論 | INTERPRETATION | MEDIUM | 依 one-sex／two-sex 與公共領域框架；須保留作者歸屬。 |
| 神秘合唱的 `uns` 未被文本限定為男性；Mahler 設定由男、女與童聲共同唱出。 | SRC-022 | Niekerk | 結論段，自 “Who is exactly speaking...” 起 | INTERPRETATION | MEDIUM | 合唱編制由作者陳述；不能由此推成 Goethe／Mahler 的現代平權宣言。 |
| Trop 將 Eternal Feminine 讀作 attraction 的一個區域，而非足以封閉整部 *Faust* 的唯一宇宙原理。 | SRC-019 | Trop | pp. 397–399、404–406 | INTERPRETATION | MEDIUM | Naturphilosophie／queer framework 是作者後來的讀法。 |
| Trop 以女性、未標性別的 `uns`、天使與 Mephistopheles 的吸引關係擾動簡單異性戀總體。 | SRC-019 | Trop | pp. 398–399、404–405 | INTERPRETATION | MEDIUM | 不能回稱 Goethe 或 Mahler 的文件化思想。 |
| Mephistopheles 使用 `Ewig-Leere`，並在終場受天使吸引，為封閉的救贖總體提供反向力量。 | SRC-003；SRC-019 | Goethe；Trop | Goethe final scene；Trop pp. 404–406 | INTERPRETATION | MEDIUM | 原典可證語句／行動；其「反向力量」功能為 Trop 分析。 |
| Mahler 1909 年致 Alma 的解釋把 Eternal Feminine 與吸引、安息／目標、愛的力量及永恆福樂相連。 | SRC-006；SRC-023 | Papanikolaou；Bauer | Papanikolaou pp. 193–194；Bauer pp. 81–82、note 24 p. 87 | DOCUMENTED CONNECTION | MEDIUM | 書信由二手學術來源轉引；未持有原始學術版全文。 |
| 該書信晚於 1906 年完成作品約三年，不能當作創作起點的直接證明。 | SRC-006 | Papanikolaou | p. 194 and n. 33 | FACT | HIGH | 可證文件時序；不代表後來解釋沒有詮釋價值。 |
| Wagner 批評 Goethe 延後 Faust 的救贖，並以自身 `redemption through love` 模式重讀 Eternal Feminine。 | SRC-021 | Grey, “Ideas of Redemption and the Total Artwork...” | approx. pp. 121、127、131–144；sections on Wesendonck letter and `Ewig-Weibliche` | CONTEXT | HIGH | 支持 Wagner reception，不支持 Wagner→Mahler 直接因果。 |
| `Das Ewig-Weibliche` 不可等同 Jungian `anima` 或 individuation。 | 控制層＋來源時序 | Editorial Charter；CORE_05 pack | claims to avoid | CONTEXT | HIGH | 現有來源無 1906 傳播證據；Jung 只能作後來比較。 |
| 終場可理解為仍需辨認、受教與繼續上升，而非 Faust 已成完成品。 | SRC-003；SRC-006 | Goethe；Papanikolaou | Goethe lines 9999–10013；Papanikolaou pp. 189–192 | INTERPRETATION | HIGH | 教學綜合；不裁定全劇唯一救贖論。 |

## 仍未納入正文的證據缺口

- 未取得 Mahler 1909 年書信的學術原文版；正文只將 Papanikolaou／Bauer 的轉引用作事後接受證據。
- 未取得 Hefling 的 Justine Mahler Faust notebook 專章，不能建立 Lipiner／Justine notebook 至 Mahler 1906 年讀法的連續傳播鏈。
- Goethe 德文來源為 Project Gutenberg 轉錄，Latham 是早期英譯；兩者都不能取代現代批判版及注釋。
- Niekerk DOCX 雖全文完整，但本地無可靠出版 venue、年份與頁碼；其 gender-history 框架只作具名競爭性解讀。
- Trop 與 Niekerk 足以證明讀法競爭，不足以裁定一個新的唯一正解；Grey 只建立 Wagner 的十九世紀重讀。
- 本章不以 Papanikolaou 的局部譜例擴張成完整總譜分析；本地仍無 Mahler VIII score／critical report。
==================================================
ORIGINAL FILE: CORE_06_EVIDENCE.md
==================================================

# CORE 06｜內部證據紀錄

本檔僅供編輯查核，不供公開刊載。Batstone 的 dissertation page 與 PDF page 相差約 11 頁；下表以 dissertation printed page 為主。SRC-001 的音樂論證針對 Mahler 前四首交響曲，本文只使用其人際、閱讀、政治與身分脈絡。SRC-006 對 Lipiner—Faust 的說法保持「可能」層級。

| Claim | Source ID | Author / title | Exact page / section / reliable local location | Evidence type | Confidence | Qualification / limitation |
|---|---|---|---|---|---|---|
| Pernerstorfer Circle 是 1870 年代 University of Vienna 學生形成的非正式、成員流動且紀錄有限的圈子。 | SRC-001 | Batstone, *Mahler, Nietzsche and the Pernerstorfer Circle* | pp. 24–25 / PDF pp. 35–36 | FACT | HIGH | 主要成員可重建，不代表有固定章程或一致教義。 |
| 圈子前身 Telyn Society 由 Adler、Pernerstorfer、Gruber、Friedjung 等於 1867 年組成。 | SRC-001 | Batstone | pp. 26–27 / PDF pp. 37–38 | FACT | HIGH | Batstone 綜合 McGrath／Ardelt 等研究。 |
| 進入大學後，聚會擴大到藝術、文學及其社會角色。 | SRC-001 | Batstone | p. 27 / PDF p. 38 | CONTEXT | HIGH | 是圈子發展的研究重建，不代表每次聚會都有同一題目。 |
| 非正式圈子與 Vienna German Students’ Reading Society 重疊；後者有年度紀錄。 | SRC-001 | Batstone | pp. 29–30 / PDF pp. 40–41 | FACT | HIGH | 閱讀會紀錄不能完整代替私人聚會內容。 |
| 圈內接觸 Wagner、Nietzsche、Schopenhauer、Goethe、Jean Paul、Beethoven。 | SRC-001 | Batstone | pp. 27–29 / PDF pp. 38–40 | FACT | HIGH | 閱讀／尊崇證明可得性，不證明對每位作者有共同解釋。 |
| 1877 年圈內人致信 Nietzsche 並稱他為教育者；Lipiner 曾談〈Schopenhauer 作為教育者〉。 | SRC-001 | Batstone | pp. 28、38 / PDF pp. 39、49 | FACT | HIGH | 證明早期 Nietzsche 接觸；不能直接連至 1906 年作品。 |
| 圈內 Nietzsche 接受可與社會改革、共同體及文化更新並讀，而非只有後來單一政治形象。 | SRC-001 | Batstone | pp. 25–30；abstract／introduction | INTERPRETATION | MEDIUM | 是 Batstone 的接受史論證；各成員立場仍有差異。 |
| Lipiner 與 Braun 於 1874 年加入，Lipiner 很快成為重要 Nietzsche 解讀者。 | SRC-001 | Batstone | pp. 28、37–39 / PDF pp. 39、48–50 | FACT | HIGH | 「重要」依講座、著作及同時代反應綜合。 |
| Lipiner 1876 年創作 *Der entfesselte Prometheus*，獲 Nietzsche 高度評價。 | SRC-001 | Batstone | pp. 37–38 / PDF pp. 48–49 | DOCUMENTED CONNECTION | HIGH | Nietzsche 評語經其書信／遺稿；不等於兩人完整思想一致。 |
| Lipiner 1878 年〈當代宗教思想更新的要素〉以古典戲劇、淨化與 Nietzsche 思想討論藝術性宗教更新。 | SRC-001 | Batstone | pp. 28、38–39 / PDF pp. 39、49–50 | CONTEXT | HIGH | 本包未含 Lipiner 原文；內容由 Batstone 研究概括。 |
| Mahler 與 Kralik 約在 1878 年經 Lipiner 進入圈子。 | SRC-001 | Batstone | p. 28 / PDF p. 39 | FACT | MEDIUM | Batstone 依 McGrath；缺 Mahler 本人同期日記確認。 |
| Lipiner 曾寫 Goethe *Faust* 藝術革新的文章。 | SRC-001 | Batstone | p. 39 / PDF p. 50 | FACT | HIGH | Batstone 依 Deutsche Zeitung 檔案；本包未含該文全文。 |
| Lipiner 與 Mahler 多年保持親近，書信與 Bauer-Lechner 回憶顯示兩人討論藝術、哲學。 | SRC-001 | Batstone | pp. 39–40 / PDF pp. 50–51 | DOCUMENTED CONNECTION | HIGH | 證明關係與討論範圍，不證明 Faust→Eighth 的特定傳播。 |
| Papanikolaou 認為 Mahler 的 Faust 觀可能早受 Lipiner 形塑。 | SRC-006 | Papanikolaou, “Linking Christian and Faustian Utopias” | pp. 194–195 and notes | INTERPRETATION | LOW–MEDIUM | 關鍵底層 McGrath／Kita／Hefling 未在本包；正文只作待查可能。 |
| Pernerstorfer 曾結合 German nationalism、socialism 及藝術／政治的共同體功能。 | SRC-001 | Batstone | pp. 31–34 / PDF pp. 42–45 | CONTEXT | MEDIUM–HIGH | 依其文章與政治生涯重建；不能用今日固定標籤簡化。 |
| Schönerer 運動走向激烈 racial antisemitism 後，Pernerstorfer 離開該陣營。 | SRC-001 | Batstone | pp. 235–236 / PDF pp. 246–247 | FACT | MEDIUM | Batstone 的身分／政治綜合；不因此洗白其他民族主義內容。 |
| Adler 與 Mahler 是具體朋友；Adler 曾買鋼琴並介紹學生。 | SRC-001 | Batstone | p. 37 / PDF p. 48 | DOCUMENTED CONNECTION | HIGH | 依傳記／檔案研究；屬人際互助，不等於作品影響。 |
| Mahler 常至 Adler 夏居作客，1901 年公開投票支持 Adler。 | SRC-001 | Batstone | p. 37 / PDF p. 48 | DOCUMENTED CONNECTION | MEDIUM–HIGH | Batstone 引 Maderthaner；支持長期關係與政治行動。 |
| 1878 年 Reading Society 解散後，圈內大致分向藝術／宗教與政治行動。 | SRC-001 | Batstone | pp. 30–31 / PDF pp. 41–42 | FACT | MEDIUM–HIGH | Batstone 接受 McGrath 的分流，但明示並非關係完全斷裂。 |
| Lipiner、Kralik、Mahler 轉向 Saga Society；Adler、Pernerstorfer、Friedjung、Braun 更投入政治。 | SRC-001 | Batstone | pp. 30–31 | FACT | MEDIUM | 是大致路線，不是每位成員此後只有單一活動。 |
| Mahler 後來仍與部分「政治派」成員往來，藝術／政治分流不是徹底決裂。 | SRC-001 | Batstone | p. 31；pp. 35–40 | FACT | HIGH | 由 Adler 等持續關係支持。 |
| Habsburg Vienna 的成員可能同時具有 German cultural、Slavic regional、Jewish ethnic/spiritual 等重疊身分。 | SRC-001 | Batstone | pp. 228–239 / PDF pp. 239–250 | INTERPRETATION | MEDIUM | Batstone 改寫 Rozenblit 模型；不可當每個人的固定配方。 |
| Mahler 的複合位置能作為共同體／文化更新問題的脈絡，不能成為作品密碼。 | SRC-001 | Batstone | pp. 228–239；study scope | INTERPRETATION | MEDIUM | 編輯綜合；正文避免單線 assimilation 或 identity determinism。 |
| Batstone 的核心音樂案例是 Symphonies Nos. 1–4，而非 Symphony No. 8。 | SRC-001 | Batstone | abstract / PDF p. 5 | FACT | HIGH | 禁止把其音樂影響論證移植到第八號。 |
| 現有 corpus 不能建立 Goethe→Wagner→Nietzsche→Lipiner→Mahler→Symphony No. 8 的因果鏈。 | SRC-001；SRC-006 | Batstone；Papanikolaou | Batstone study scope；Papanikolaou pp. 186、194–195 | CONTEXT | HIGH | 可證接觸與脈絡，不可證每一箭頭的 compositional causation。 |

## 仍未納入正文的證據缺口

- 缺 Mahler 青年日記、完整書信、Lipiner 相關原文與 Faust 論述，無法重建具體談話內容。
- 缺 Stephen E. Hefling〈Justine Mahler’s Faust Notebook〉，不能驗證 Lipiner／Justine notebook 至 Mahler 第八號的最短傳播鏈。
- 缺 William J. McGrath 專書、Caroline A. Kita 學位論文與 Batstone 2023 修訂專書，現有網絡史主要依賴 Batstone 2019 單一完整研究者。
- Papanikolaou 對 Lipiner 的連結為濃縮的可能性陳述，且其關鍵註腳來源不在本包。
- 不把 Batstone 對 Wunderhorn symphonies 的 Nietzsche 音樂分析套用到 1906 年；本章不提出第八號的直接思想來源。
- 複合身分模型用來阻止單線敘事，不代表已完成 Mahler 的 Jewish／German／Slavic identity 研究。
==================================================
ORIGINAL FILE: CORE_07_EVIDENCE.md
==================================================

# CORE 07｜內部證據紀錄

本檔僅供編輯查核，不供公開刊載。SRC-023 Bauer 為影像掃描，頁碼均按印刷頁 76–87 核對；其 Latin–German mapping 在 pp. 80–81。Bauer 的 `klingende Pneumatologie`、personal credo 與 Goethe-as-key 是具名詮釋，不升格為 Mahler 的系統神學。SRC-006 同為影像掃描，採印刷頁碼。

| Claim | Source ID | Author / title | Exact page / section / reliable local location | Evidence type | Confidence | Qualification / limitation |
|---|---|---|---|---|---|---|
| *Veni Creator Spiritus* 是 Western Latin Pentecost hymn，與較晚的 sequence *Veni Sancte Spiritus* 不同。 | SRC-023 | Bauer, “«Veni Creator Spiritus»...” | p. 79 | FACT | HIGH | Bauer 為 specialist synthesis；本章不展開完整 chant history。 |
| 核心傳承包含六個 Ambrosian stanzas；doxology 與 `Da gaudiorum praemia` 有後來／次生傳承問題。 | SRC-023 | Bauer | p. 79 | CONTEXT | HIGH | 未持有底層 critical apparatus，不能獨立裁定全部異文。 |
| Hrabanus Maurus 作者歸屬只能保留式表述。 | SRC-023 | Bauer | p. 79，`Vieles spricht dafür` | CONTEXT | HIGH | 祈禱匿名流傳，手稿互有差異；不可寫成確定作者。 |
| Hymn 自中世紀用於 Pentecost Vespers／Terce，也用於 councils、synods 等場合開端。 | SRC-023 | Bauer | p. 79 | FACT | HIGH | 描述歷史與現代 German Catholic use；不宣稱每次場合主觀目的相同。 |
| 讚歌具有共同體呼求而非孤立藝術家獨白的基本功能。 | SRC-023 | Bauer | pp. 79–81 | INTERPRETATION | HIGH | 依禮儀使用與複數／集體語彙作教學綜合。 |
| `Veni`、`visita`、`imple` 是向 Holy Spirit 發出的祈求／命令式動詞。 | SRC-023 | Bauer | p. 80 | FACT | HIGH | 命令式表示迫切祈求，不是人對神的支配。 |
| `Mentes tuorum visita / Imple superna gratia / quae tu creasti pectora` 請求探訪並以從上而來的恩典充滿所創造的人心。 | SRC-023 | Bauer | p. 80 | FACT | HIGH | `mentes／pectora` 中文為解釋性轉述，不主張唯一 philological translation。 |
| `gratia` 是外來／從上而來的恩典，不是人努力後所得報酬。 | SRC-023；SRC-006 | Bauer；Papanikolaou | Bauer pp. 80、83；Papanikolaou pp. 189–191 | CONTEXT | HIGH | 神學區分依語法；不建立完整 doctrine of grace。 |
| 第二節稱聖靈為 `Paraclitus`、gift、`fons vivus, ignis, caritas` 與 `spiritalis unctio`。 | SRC-023 | Bauer | p. 80 | FACT | HIGH | 各詞為相關稱謂／意象，不是可任意互換的同義詞。 |
| `caritas` 在此指基督宗教的愛／仁愛，不能直接等同浪漫愛情或愛欲（`Eros`）。 | SRC-023 | Bauer | pp. 80、83–84 | CONTEXT | HIGH | Bauer 引聖靈論傳統；正文只作必要區分。 |
| `Infirma nostri corporis / Virtute firmans perpeti` 請求以力量堅固身體軟弱。 | SRC-023 | Bauer | pp. 80、83 | FACT | HIGH | `virtus` 以力量／能力解釋，不限於道德美德。 |
| `Accende lumen sensibus / Infunde amorem cordibus` 請求點燃感官／心智之光並把愛灌注人心。 | SRC-023；SRC-006 | Bauer；Papanikolaou | Bauer pp. 80、83–84；Papanikolaou pp. 188–189 | FACT | HIGH | illumination 是教學解釋詞；不等同舞台光或泛稱能量。 |
| 其他祈求包括驅退敵對力量、賜和平、引導避惡、認識父與子並持守聖靈信仰。 | SRC-023 | Bauer | pp. 80–81 | FACT | HIGH | 依完整 Latin mapping；正文未處理所有傳本差異。 |
| 結尾 doxology 把讚歌放回 Father、risen Son 與 Paraclitus 的三一讚頌。 | SRC-023 | Bauer | pp. 81、84–85 | FACT | HIGH | Mahler 版本的文字與次序由 Bauer mapping 支持；無獨立 score verification。 |
| Mahler 重排 stanza／verse order，重複、刪除、替換並添加文字；Bauer 稱其設定為七節半。 | SRC-023 | Bauer | pp. 79–81 | FACT | HIGH | 直接研究重現 mapping；本包無 score／critical report 獨立核對 bars。 |
| Mahler 把原第四節身體軟弱／力量兩行置於 light／love 之前，再返回其他節次。 | SRC-023 | Bauer | pp. 80–81 table | FACT | HIGH | 作選擇性示例，不聲稱列完所有重排。 |
| Mahler 的改編仍保留 Holy Spirit address 與核心 petitions，不能單憑重排宣告文本完全世俗化。 | SRC-023 | Bauer | pp. 79–85 | INTERPRETATION | MEDIUM–HIGH | 編輯綜合；不宣稱 Mahler 接受全部 Catholic doctrine。 |
| Goethe 曾稱 hymn 為 `Appell ans Genie`；Mahler 未必知道 Goethe 1820 translation。 | SRC-023；SRC-006 | Bauer；Papanikolaou | Bauer p. 77 and note 6；Papanikolaou p. 186 | CONTEXT | MEDIUM | 支持 artistic-creativity bridge；不證明直接文本傳播。 |
| Mahler 後來以被 `spiritus creator` 抓住／驅策形容創作。 | SRC-023；SRC-006 | Bauer；Papanikolaou | Bauer pp. 78–79；Papanikolaou p. 186 | DOCUMENTED CONNECTION | MEDIUM | 事後回憶具有傳奇化／自我呈現性，不是創作現場紀錄。 |
| 草圖與 Alma 回憶使「一瞬間完整降臨」的創作神話變得更複雜。 | SRC-023 | Bauer | pp. 78–79 | CONTEXT | MEDIUM | Bauer 的 genesis 綜合；本包未持有草圖／書信原件。 |
| Adorno 批評作品混淆藝術與宗教、以祈求聖靈之名崇拜音樂自身。 | SRC-023 | Bauer | p. 77 | INTERPRETATION | MEDIUM | Bauer 轉引 Adorno；本包未含 Adorno 原文，不展開完整批評史。 |
| Bauer 將第一部讀作 dogmatically 不完全一致、但近似 personal credo／`klingende Pneumatologie`。 | SRC-023 | Bauer | pp. 82–85 | INTERPRETATION | MEDIUM | 必須具名歸屬，不可改寫成 Mahler 自述或學界共識。 |
| 第一部的基本模型是 invocation／reception：人承認不足，向外請求光、愛、力量、和平與引導。 | SRC-023 | Bauer | pp. 79–84 | INTERPRETATION | HIGH | 依動詞與禮儀功能的教學綜合；不提前完成 CORE 08 的跨部論證。 |

## 仍未納入正文的證據缺口

- Bauer 所依據的 Le Gall、Stock、Lausberg 等 critical hymnology 不在本包，不能獨立裁定全部手稿異文、作者與旋律史。
- 本地無 Mahler VIII score／critical report；不自行提供 bar numbers、配器、聲部分配、反覆次數或 rehearsal-level deployment。
- Mahler letters、sketches 與早期 programmes 主要經 Bauer／Papanikolaou 轉引；不能據此建立 systematic theology 或精確 genesis chronology。
- Adorno 僅經 Bauer 轉引，本章只用來標示「藝術／宗教混淆」的爭議，不聲稱已完整呈現其 Mahler 批評。
- `western_veni_creator_dossier.pdf` 為 0-byte failed acquisition，未提供任何證據。
- 本章有意不回答兩文本為何統一；只建立 CORE 08 必須使用的 hymn 歷史身分、祈求動詞與術語差異。

==================================================
ORIGINAL FILE: CORE_08_EVIDENCE.md
==================================================

# CORE 08｜內部證據紀錄

本檔供編輯查核。Bauer 與 Papanikolaou 頁碼為印刷頁；Papanikolaou 掃描頁已重新核對。CORE 08 假定讀者已讀 CORE 03–05 與 CORE 07；下列讚歌基礎列只核對本章的壓縮回顧，正文不再教授其作者、禮儀史或逐項祈求。

| Claim | Source ID | Author / title | Exact page / section / reliable location | Evidence type | Confidence | Qualification / limitation |
|---|---|---|---|---|---|---|
| 第一部使用 Western Latin Pentecost hymn *Veni Creator Spiritus*，第二部使用 Goethe *Faust II* Schlußszene。 | SRC-006；SRC-023；SRC-003 | E. Papanikolaou；D. Bauer；Goethe | Papanikolaou pp. 183–184；Bauer pp. 79–80；Goethe `Bergschluchten`, local line 9713 ff. | FACT | HIGH | 文本身分不等於證明最初已有統一 programme。 |
| Hymn 傳承匿名且有歧異；Hrabanus Maurus 作者歸屬只能保留表述。 | SRC-023 | Bauer, “«Veni Creator Spiritus»” | p. 79 | CONTEXT | HIGH | Bauer 說 `Vieles spricht dafür`，不是確定歸屬。 |
| Hymn 用於 Pentecost Vespers／Terce，也見於 councils、synods 等開端。 | SRC-023 | Bauer | p. 79 | FACT | HIGH | Specialist synthesis；底層批判版不在目前來源。 |
| `Veni`、`visita`、`imple` 等是群體向 Holy Spirit 發出的祈求語法。 | SRC-023 | Bauer | pp. 80–81 | FACT | HIGH | 命令式在祈禱中是迫切呼求，不表示支配。 |
| Hymn 請求從上而來的恩典、光、愛、力量、和平、引導、知識與信德。 | SRC-023 | Bauer | pp. 80–84 | FACT | HIGH | 各概念相關但功能不同。 |
| Hymn 的複數／共同體語言使其不同於孤獨藝術家的自我歌頌。 | SRC-023 | Bauer | pp. 79–83 | INTERPRETATION | HIGH | 依文法與禮儀使用作教學綜合。 |
| Mahler 重排、重複、省略、替換並添加 hymn words。 | SRC-023 | Bauer | pp. 79–81，full text/mapping | FACT | HIGH | 未獨立核對 critical score 的每一小節。 |
| `Creator Spirit` 在 hymn 脈絡指 Holy Spirit 的創造／更新行動，不直接等同藝術家創造力。 | SRC-023 | Bauer | pp. 82–83 | CONTEXT | HIGH | 人類創造力是可討論的後來橋接，不是原詞替換。 |
| `Spiritus` 與 Goethe `Geist` 不能因英譯同為 spirit 就視為同一概念。 | SRC-003；SRC-023 | Goethe；Bauer | Goethe final scene；Bauer pp. 80–84 | INTERPRETATION | HIGH | 依語境分譯的術語規則。 |
| `gratia` 是恩典；`caritas` 是基督宗教的愛／仁愛，均不應與 Goethe `Liebe` 或後來的愛欲（`Eros`）混同。 | SRC-003；SRC-006；SRC-023 | Goethe；Papanikolaou；Bauer | Goethe local lines 9827–9831；Papanikolaou pp. 185、189–191；Bauer pp. 80、83–84 | CONTEXT | HIGH | 可比較關係不等於語義同一。 |
| `Das Ewig-Weibliche` 與女性角色、牽引及上升相關，卻不能等同 Gretchen、Mater Gloriosa、愛、恩典、女性本質、`anima` 或單一形上原理。 | SRC-003；SRC-019；SRC-022 | Goethe；Trop；Niekerk | Goethe local lines 10025–10033；Trop pp. 397–406；Niekerk local paras. 124–154 | INTERPRETATION | HIGH | 本章只把「牽引／上升」作為跨部可比較功能；多義與競爭性性別閱讀由 CORE 05 完整建立。 |
| 第一部的 invocation／reception 與第二部的 rescue／intercession／teaching 可形成回應結構。 | SRC-003；SRC-006；SRC-023 | Goethe；Papanikolaou；Bauer | Goethe local lines 9823–10013；Papanikolaou pp. 188–193；Bauer pp. 80–84 | INTERPRETATION | MEDIUM | 本書跨文本綜合，不是 Mahler 明列對照表。 |
| Faust 的土地創造工程與 Spirit 的創造／更新不能等同，前者仍受倫理檢驗。 | SRC-003；SRC-019；SRC-023 | Goethe；Trop；Bauer | Goethe Act V；Trop pp. 395–404；Bauer pp. 82–83 | INTERPRETATION | HIGH | 對照用來限制自我神化，不否認工程願景的正面成分。 |
| Part II Angels passage uses material connected to Part I `accende lumen sensibus, infunde amorem cordibus` theme. | SRC-006 | Papanikolaou | pp. 188–189，Examples 11.1–11.2 | DOCUMENTED CONNECTION | HIGH | 掃描頁與譜例已核對；這是研究者 score analysis。 |
| Gretchen supplication／teaching passage recalls Part I `imple superna gratia` material. | SRC-006 | Papanikolaou | pp. 189–191，Examples 11.3–11.6 | DOCUMENTED CONNECTION | HIGH | 不把 Gretchen 等同 Holy Spirit 或 Mater Gloriosa 等同 grace。 |
| Webern 傳述 Mahler 稱 `accende lumen sensibus` 為通往 Faust ending 的 bridge／pivot。 | SRC-023 | Bauer | p. 84 | DOCUMENTED CONNECTION | MEDIUM | Secondary report，不是現存 Mahler autograph statement。 |
| Chorus Mysticus 以莊嚴合唱聲響承載 Goethe 超越性文字，開篇 E-flat 主題於全曲末回返。 | SRC-006 | Papanikolaou | pp. 192–194、198，Examples 11.9–11.11 | DOCUMENTED CONNECTION | HIGH | 音樂／語義意義屬 Papanikolaou 分析，不是唯一聽法。 |
| `Christian and Faustian utopias` 是 Papanikolaou 的研究框架。 | SRC-006 | Papanikolaou | pp. 183–198 | INTERPRETATION | HIGH | 不提升為 Mahler 親筆 programme。 |
| 沒有 concrete evidence 證明 Mahler 在 composition 起點已想到 Faust。 | SRC-006 | Papanikolaou | p. 186，opening paragraph | FACT | HIGH | 缺證不等於證明後來任意拼接。 |
| Mahler 關於被 `spiritus creator` 攫住與閃電般靈感的敘述是回顧性材料。 | SRC-006；SRC-023 | Papanikolaou；Bauer | Papanikolaou p. 186；Bauer pp. 78–79 | CONTEXT | MEDIUM | 可支持自我敘述／接受史，不獨立證明 exact genesis。 |
| Mahler 致 Alma 將 Faust、愛與創造相連的文字屬作品完成後文件。 | SRC-006 | Papanikolaou | pp. 193–194，esp. p. 194 n.33 | DOCUMENTED CONNECTION | HIGH | 可能是真實後來理解，不可倒推 1906 起初方案。 |
| 完成作品中的跨部主題關係支持最終 pairing 有實質構思。 | SRC-006；SRC-023 | Papanikolaou；Bauer | Papanikolaou pp. 188–198；Bauer p. 84 | INTERPRETATION | MEDIUM | 與 exact compositional chronology 分開。 |
| 文本可比較性、完成作品整合與最初形成史是三種不同問題；前兩者不能填補第三者的證據空白。 | SRC-003；SRC-006；SRC-023 | Goethe；Papanikolaou；Bauer | Goethe final scene；Papanikolaou pp. 186、188–198；Bauer pp. 78–84 | INTERPRETATION | HIGH | 本書的方法性區分；完成作品整合不證明初始同時構思，起點缺證也不證明任意拼接。 |
| 作品喚起交響曲、宗教合唱、神劇／戲劇等多種體裁記憶。 | SRC-006；SRC-013 | Papanikolaou 2017；Papanikolaou, symphonic-mass study | Papanikolaou 2017 pp. 183–184、195–198；SRC-013 relevant genre sections | INTERPRETATION | MEDIUM | 「穿交響曲外衣的彌撒」是歷史／學術描述，不是正式改名。 |
| Bauer 的 `klingende Pneumatologie`／personal-credo 讀法與 Adorno 對藝術—宗教混淆的批評提供方向不同的完成作品評價。 | SRC-023 | Bauer, “«Veni Creator Spiritus»” | pp. 77、82–85 | INTERPRETATION | MEDIUM | Adorno 僅經 Bauer 轉引；兩者是具名觀點，不是涵蓋全學界的兩大派。 |
| 兩部以回應而非等同構成整體：人的追求受外來恩典、照明與關係性轉化質詢。 | SRC-003；SRC-006；SRC-023 | Goethe；Papanikolaou；Bauer | Goethe local lines 9823–10013；Papanikolaou pp. 188–194；Bauer pp. 80–84 | INTERPRETATION | MEDIUM | 本書綜合，不是唯一意圖或學界共識。 |

## 未解但不阻擋成稿的限制

- 缺完整 hymn critical apparatus、chant history 與目前可直接查核的 Bauer 本體；本章沿用已核准 baseline 中對 Bauer 掃描頁的逐頁紀錄，不新增超出其範圍的主張。
- 未取得 Mahler autograph sketches、critical score report 與完整書信版，故不重建 exact compositional chronology，也不提供全曲逐小節 motivic map。
- Papanikolaou 的 utopia／symphonic-mass、Bauer 的 pneumatological reading 及 Devutsky 的 universal mystery 都維持具名詮釋，不合併為 Mahler 唯一 programme。


==================================================
ORIGINAL FILE: CORE_09_EVIDENCE.md
==================================================

# CORE 09｜內部證據紀錄

本檔供編輯查核。CORE 09 只處理尺度、集體發聲、類型越界、公共權威與後來接受；不重建 1910 Munich 首演，不提供精確表演人數、舞台配置或獨立總譜分析。Barham 本地 `.doc` 無可靠出版頁碼，以章節／電影段落定位；Devutsky 僅使用印刷頁 107 的英文摘要。

| Claim | Source ID | Author / title | Exact page / section / reliable location | Evidence type | Confidence | Qualification / limitation |
|---|---|---|---|---|---|---|
| *Veni Creator Spiritus* 的基本語法是祈禱共同體向創造者聖靈發出呼求，而非孤立藝術家的自我宣告。 | SRC-023（由 CORE 07 canonical Evidence 繼承） | Dorothee Bauer, “«Veni Creator Spiritus»...” | pp. 79–84；CORE_07_EVIDENCE 對應列 | CONTEXT | HIGH | CORE 09 只壓縮使用已教知識，不重教 hymnology；Bauer 全文不在本次 CORE 09–10 scholarly-source ZIP。 |
| Goethe 終場包含隱修者、天使、蒙福孩童、Doctor Marianus、悔罪女性、Mater Gloriosa 與 Chorus Mysticus 等個別／集體發言位置。 | SRC-003 | Goethe, *Faust II* | local lines 9713–10033 | FACT | HIGH | Project Gutenberg 轉錄不是批判版；角色結構不證明 Mahler 必然需要某一精確編制。 |
| Faust 在山谷終場沒有最後英雄獨白；救援、代求、教導、准允與集體收束分配給不同角色。 | SRC-003 | Goethe, *Faust II* | lines 9823–9831、9980–10033 | FACT | HIGH | 「關係事件」是依戲劇分工所作的教學綜合。 |
| 大型宗教音樂在十九世紀跨越禮儀／音樂會、神聖／世俗與 church／concert hall 邊界。 | SRC-013 | E. Papanikolaou, “Romanticism as Border Crossing: The Case of the Symphonic Mass” | pp. 63–75，尤其 68–75 | CONTEXT | HIGH | 類型史背景；不能據此把《第八號》客觀分類為彌撒或建立直接影響。 |
| 十九世紀 symphonic Mass 的公共化可被理解為私人／個人宗教詮釋進入公共領域。 | SRC-013 | Papanikolaou, “Romanticism as Border Crossing” | p. 74 | INTERPRETATION | MEDIUM–HIGH | 是 Papanikolaou 的類型史綜合；CORE 09 以「近似儀式」而非正式禮儀表述。 |
| Mahler 對 *Faust II* 終場作出 monumental treatment，作品同時喚起交響、合唱、宗教與戲劇類型。 | SRC-006 | E. Papanikolaou, “Linking Christian and Faustian Utopias” | pp. 183–184、195–196 | INTERPRETATION | HIGH | `monumental treatment` 與類型判讀屬具名研究，不是 Mahler 自述。 |
| Papanikolaou 將 symphony 視為承載類型，並列 motet、cantata、oratorio、religious drama、symphonic cantata、meta-opera 等競爭性稱呼。 | SRC-006 | Papanikolaou, “Linking Christian and Faustian Utopias” | pp. 195–196 | INTERPRETATION | HIGH | 不把任何名稱升格為唯一客觀分類。 |
| Roller 轉述 Mahler 在 Munich 排練後把《第八號》稱作「我的彌撒」。 | SRC-006 | Papanikolaou, “Linking Christian and Faustian Utopias” | p. 196（轉引 Alfred Roller） | DOCUMENTED CONNECTION | MEDIUM | 二手轉述；本包無 Roller 原文。只證後來自我描述，不能改名為正式 Mass。 |
| Devutsky 以 `symphony-mystery` 與 Divine–Human–Divine-Human 三元模型解釋全曲。 | SRC-002 | Vladislav E. Devutsky, “The Universal Mystery of 1906” | printed p. 107, English abstract | INTERPRETATION | HIGH | 2016 年模型，不是 Mahler 文件化 programme；俄文正文文字層損壞，正文細節不使用。 |
| 現有材料不足以證成《第八號》與某套 Wagner 式 *Gesamtkunstwerk*、Reinhardt／`Massenregie` 的直接關係。 | Research control / missing set | `CORE_09.md`; `MISSING_FULL_TEXT.md` | CORE_09 Evidence gaps；MF-014、MF-016 | CONTEXT | HIGH | 缺 Peter Revers 全文、完整 Kappel 卷與相關 primary evidence；正文只把 *Gesamtkunstwerk* 作保留式分析標籤。 |
| 作品的集體聲音與經典／宗教語彙可產生普世性與權威感。 | SRC-006 | Papanikolaou, “Linking Christian and Faustian Utopias” | pp. 183–184、195–198 | INTERPRETATION | MEDIUM | 「普世性」是藝術／修辭主張，不證明政治包容或實際代表所有人。 |
| 表演與聆聽共同體是演出中暫時形成的群體，不能與民族、宗教或抽象人類共同體互換。 | CORE 01–08 continuity base；SRC-006 | Canonical terminology decisions；Papanikolaou | `community` terminology decision；SRC-006 pp. 183–198 | INTERPRETATION | HIGH | 全書方法性限定；不聲稱來源直接提出同一中文分類。 |
| Fassbinder 在 *Chinese Roulette*、*Lili Marleen*、*Berlin Alexanderplatz* 使用《第八號》片段，使其肯定、德國身分、集體性與救贖承諾被重新配置。 | SRC-016 | Jeremy Barham, “A Time of Gifts: Mahler's Eighth, Fassbinder's Cinema, and Musical Politics” | named sections `Chinese Roulette (1976)`、`Lili Marleen (1980)`、`Berlin Alexanderplatz (1980)` and conclusion | FACT / INTERPRETATION | HIGH | 電影使用為 FACT；政治／文化意義為 Barham 分析。只屬後來接受，不能回投 1906／1910。 |
| *Chinese Roulette* 在抵達前切斷〈Blicket auf〉，以失靈溝通反向測試音樂的普世和解姿態。 | SRC-016 | Barham | `Chinese Roulette (1976)` section | INTERPRETATION | HIGH | Barham 對影像／音樂配置的分析；不是 Fassbinder 明示的唯一意圖。 |
| *Lili Marleen* 讓終曲同時承載戰後文化崇高、德語身分與未完成關係；*Berlin Alexanderplatz* 則以不得救人物反襯音樂的超越承諾。 | SRC-016 | Barham | `Lili Marleen (1980)`；`Berlin Alexanderplatz (1980)` | INTERPRETATION | HIGH | 後來再語境化個案，不代表首演接受史。 |
| Monumentality 可成為 collective gift／utopian resource，也可能形成壓倒個體的權威感。 | SRC-006；SRC-016 | Papanikolaou；Barham | Papanikolaou pp. 197–198；Barham conclusion | INTERPRETATION | MEDIUM | 不是「規模必然導向政治」的因果命題；批判方向目前只有具名個案與二手材料。 |

## 重要限制

- 無權威總譜／校勘報告，故不獨立核對精確編制、聲部分配、空間設計或小節關係。
- 無 1910 Munich programme、宣傳、報刊、場地檔案與可信 performer-count dossier；正文不使用「千人交響曲」來源或任何確切人數。
- 無 Peter Revers 的 `Massenregie` 全文與完整 *Total Work of Art* 研究卷；不建立 Reinhardt、Wagner 或 *Gesamtkunstwerk* 的直接因果。
- Barham 是後來電影接受研究；其政治解讀只證明作品可被重新使用，不能代表 1906 意圖或 1910 共同理解。
- Papanikolaou、Devutsky 對類型、普世性與神秘劇的說法均保持具名歸屬；兩位作者不構成完整學界共識。

==================================================
ORIGINAL FILE: CORE_10_EVIDENCE.md
==================================================

# CORE 10｜內部證據紀錄

本檔供編輯查核。CORE 10 比較 competing frameworks，不把任何框架升格為 Mahler 唯一 programme。Adorno 只經 SRC-011 Arbo 的二手研究與 SRC-006／SRC-016 轉引進入本章；無 Adorno 原文，不重建其對《第八號》的完整逐段批評。

| Claim | Source ID | Author / title | Exact page / section / reliable location | Evidence type | Confidence | Qualification / limitation |
|---|---|---|---|---|---|---|
| 完成作品把不同文本來源組織為可跨部記憶的整體，但不證明兩部最初同時構思。 | SRC-006；CORE 08 canonical base | Papanikolaou；CORE_08_DRAFT／EVIDENCE | Papanikolaou pp. 186、188–198；CORE 08 `finished-work integration`／`initial compositional genesis` | INTERPRETATION | HIGH | 沒有 Mahler sketches、critical report 與完整 primary letters；CORE 10 不新增 score-level finding。 |
| *Veni Creator Spiritus* 是向創造者聖靈祈求恩典、照明、愛、力量、和平與信仰的歷史祈禱。 | SRC-023（由 CORE 07 canonical Evidence 繼承） | Dorothee Bauer | pp. 79–84；CORE_07_EVIDENCE | FACT / CONTEXT | HIGH | 不把宗教身分改寫成人類創造力；SRC-023 不在本次專用來源包，主張由 canonical CORE 07 繼承。 |
| Goethe 終場把 *Streben*、從上而來的愛、救援、代求、教導與上升置於同一戲劇次序。 | SRC-003 | Goethe, *Faust II* | lines 9823–9831、9980–10033 | FACT | HIGH | 原典可證字詞與次序，不能證 Mahler 私人神學。 |
| Papanikolaou 推測 Mahler 的作品可能形成 post-Christian *Kunstreligion*／personal credo。 | SRC-006 | Papanikolaou, “Linking Christian and Faustian Utopias” | p. 197 | INTERPRETATION | MEDIUM | 原文使用 `Perhaps`；不得去除推測性或當成 Mahler 自述。 |
| Roller 轉述 Mahler 把《第八號》稱作「我的彌撒」。 | SRC-006 | Papanikolaou（轉引 Alfred Roller） | p. 196 | DOCUMENTED CONNECTION | MEDIUM | 二手轉述；證明後來宗教性自我描述，不建立正式 liturgical genre。 |
| 《第八號》喚起 symphony、choral symphony、oratorio、religious drama、symphonic cantata 等競爭性類型記憶。 | SRC-006 | Papanikolaou | pp. 195–196 | INTERPRETATION | HIGH | 類型標籤是分析鏡頭，不是單選題或 Mahler programme。 |
| Devutsky 的 `symphony-mystery`、Divine–Human–Divine-Human 與 Paradise 邊界模型是一種強整體讀法。 | SRC-002 | Devutsky, “The Universal Mystery of 1906” | p. 107 English abstract | INTERPRETATION | HIGH | 2016 年模型；不是 Mahler 文件化命名。正文不採俄文正文的未核細節。 |
| Papanikolaou 以 Christian／Faustian utopias 與 utopian impulse 解釋兩部交會和終曲肯定。 | SRC-006 | Papanikolaou | pp. 183–198，尤其 197–198 | INTERPRETATION | HIGH | 具名研究框架；不代表完整學界共識。 |
| 烏托邦可作為「尚未實現整體暫時可被經驗」的編輯性框架，而不是 Mahler 提供的制度藍圖。 | SRC-006；SRC-011 | Papanikolaou；Arbo | Papanikolaou pp. 197–198；Arbo pp. 138–144 | INTERPRETATION | MEDIUM | 本書綜合；須保留來源差異，不能寫成 Mahler 自述。 |
| humanist／metaphysical 可分別凸顯人的關係與超出人的創造／死亡問題，但都不是中性事實分類。 | SRC-003；SRC-006 | Goethe；Papanikolaou | Goethe lines 9713–10033；Papanikolaou pp. 183–198 | INTERPRETATION | MEDIUM | 編輯性比較框架；不主張來源使用完全相同的標籤。 |
| Papanikolaou 將《第八號》描述為 affirmation，並把 monumentality 與其樂觀姿態相連。 | SRC-006 | Papanikolaou | p. 197 | INTERPRETATION | HIGH | 作者的研究判斷；不能由規模本身推導真誠、包容或政治進步。 |
| 神秘合唱在文本上以暫逝／譬喻、不可充分達成／描述之事在此完成及永恆女性牽引上升收束全劇。 | SRC-003 | Goethe, *Faust II* | lines 10025–10033 | FACT | HIGH | Project Gutenberg 轉錄；無批判校勘。正文不將永恆女性定義為單一實體。 |
| 「肯定轉化可能」不等於肯定 Faust 所有行動；「共同發聲值得嘗試」不等於共同體已代表所有人。 | SRC-003；CORE 01–09 continuity | Goethe；canonical sequence | Goethe Act V／final scene；CORE 01、03–05、09 | INTERPRETATION | HIGH | 全書倫理與共同體限制的綜合，非來源中的單句命題。 |
| Arbo 將 Adorno 的 Mahler 理解為保存個別材料、使細節抵抗封閉總體，並由否定保存烏托邦可能。 | SRC-011 | Alessandro Arbo, *Dialettica della musica: Saggio su Adorno* | pp. 53–59、124–130、138–144 | INTERPRETATION | MEDIUM–HIGH | Arbo 對 Adorno 的二手重建；主要談 Mahler 整體，不是 Adorno 對《第八號》的完整分析。 |
| 在 Arbo 的重建中，Mahler 不放棄 totality，但避免把它變成壓迫 particular 的工具；negative utopia 依賴未被封閉和解的差異。 | SRC-011 | Arbo | pp. 55–59、129–130、138–144 | INTERPRETATION | MEDIUM–HIGH | 只作反讀原則；不聲稱 Arbo／Adorno直接裁決 CORE 10 所有文本問題。 |
| Barham 證明《第八號》在 Fassbinder 電影中可被重置為德國身分、失去的和解、utopian gift、否定與社會符號。 | SRC-016 | Jeremy Barham, “A Time of Gifts...” | `Chinese Roulette`、`Lili Marleen`、`Berlin Alexanderplatz`、conclusion | FACT / INTERPRETATION | HIGH | 電影使用為 FACT；文化意義為 Barham 分析。不能回投至 1906 或 1910。 |
| 後來接受能改變作品的公共意義，卻不等於原始意圖。 | SRC-016；terminology base | Barham；CORE 01–08 terminology | Barham full chapter；`reception / reception history` decision | CONTEXT | HIGH | 方法性區分；正文以後來使用說明意義開放，不以之替代作品歷史來源。 |
| 缺 Adorno 原文與系統性 Mahler VIII 接受史，現階段不能公平裁決「肯定」與完整批判傳統。 | Research control | `CORPUS_AUDIT.md`; `MISSING_FULL_TEXT.md` | Weak areas；MF-031 | CONTEXT | HIGH | 這是本章最重要的 evidence limitation。 |
| 對作品較完整的帶限答案：交響曲組織巨型公共行動，使歷史祈禱與 Goethe 救贖難題互相限制，讓尚未實現的更新暫時成形。 | SRC-003；SRC-006；SRC-011；SRC-016；CORE 01–09 | Goethe；Papanikolaou；Arbo；Barham；canonical sequence | listed locations above | INTERPRETATION | MEDIUM | 本書的最終綜合，不是 Mahler programme 或學界共識；「暫時」明示藝術展示與歷史實現的差別。 |

## 重要限制

- 無完整 Mahler 書信學術版、草稿、autograph、首演 programme 或同時代報刊；不確定界定 1906 意圖與 1910 公共定位。
- Mahler 1909 年對 *Das Ewig-Weibliche* 的解讀只經 Papanikolaou 轉引，且作者明示為作品完成三年後的 ex post facto 材料；正文不把它當 1906 programme。
- 無 Adorno, *Mahler: A Musical Physiognomy* 原文；Arbo 只能提供二手理論重建，Barham 只能提供後來接受個案。
- 無系統性 Mahler VIII 接受史；Papanikolaou、Devutsky、Arbo、Barham 代表可區分的鏡頭，不代表完整學界版圖。
- 無權威總譜／critical report；任何音樂整合主張均繼承 CORE 08 已歸屬於研究者的證據，不新增精確小節、配器或完整形式論。
