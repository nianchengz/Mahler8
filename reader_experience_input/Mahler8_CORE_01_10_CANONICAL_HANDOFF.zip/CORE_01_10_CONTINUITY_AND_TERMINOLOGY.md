==================================================
ORIGINAL FILE: CORE_01_08_CONTINUITY_AUDIT.md
==================================================

# CORE 01–08｜全序列連續性稽核

狀態：`continuity-canonical / ready for CORE 09–10 handoff`

本輪以兩份 handoff manifest、兩個 canonical aggregate 內的十六份 Draft／Evidence，以及既有 review／continuity 裁決為權威。工作範圍是章界、重複、術語與證據安全的連續性編輯；未進行新的廣泛研究。

## 逐章變更紀錄

| 章 | 連續性問題 | 變更 | 正文／Evidence | 術語決定 | 留待 CORE 09–10／Final Editorial |
|---|---|---|---|---|---|
| CORE 01 | 與 CORE 06 重複 Pernerstorfer 圈人物、1878 講題與政治／藝術分流；`提供`、`鼓勵` 容易暗示單向思想傳授。 | 刪去 Lipiner 講題與具名分流細節；政治段改為最低匿名例；圈子段只保留非正式網絡、共同閱讀不等於因果、後來分流三項功能；明示完整網絡史由 CORE 06 承擔。 | 正文：中度修訂。Evidence：未改；保留的主張均由原列支持，刪除正文細節不需新增證據。 | `脈絡` 與 `影響` 分開；共同體按政治／文化功能限定。 | CORE 10 若再談公共共同體，不得把城市政治、青年網絡與演出共同體混成一詞。 |
| CORE 02 | 無實質重複；需保持「為何成為共同語言」而不預講完整故事。 | 原文保留。順讀確認其接受史任務與 CORE 01、03 分立。 | 正文：未改。Evidence：未改。 | `接受史` 不等於 Mahler 的直接 `影響`。 | 最終編輯只需做全書人名／作品名格式一致性檢查。 |
| CORE 03 | 必須讓 CORE 05 不必重教 Gretchen 悲劇、Faust 責任與她的持續重要性。 | 原文已完整建立受害史、牢獄判斷、獨立得救，以及終場代求／教導，故不增寫。 | 正文：未改。Evidence：未改。 | `得救` 用於 Gretchen 的事件／狀態；`責任` 不被後續救贖取消。 | 現代 Goethe 批判版與異文問題留待進階／Final Editorial。 |
| CORE 04 | 原章末直接跳向跨部整合，越過 CORE 05；CORE 04／05 的救贖與永恆女性章界需要明示。 | 章末改為把完整救贖機制交給本章，下一步只把 *Das Ewig-Weibliche* 的多義交給 CORE 05；跨部比較延後至 CORE 08。 | 正文：小幅但實質的章界修訂。Evidence：只作 `caritas`／`Eros` 術語正規化，未改證據內容或信心。 | `Streben`、責任、得救、從上而來的愛、恩典、代求、教導、上升、轉化不得互換。 | Eckermann 原始／批判版仍缺；不建立單一系統神學。 |
| CORE 05 | 需依賴 CORE 03／04 而非重教 Gretchen 與救贖；並把歧義完整交給 CORE 08。 | 角色段明確回指 CORE 03／04；章末規定 CORE 08 只可使用牽引／上升等可證功能，不得把永恆女性改名為愛、恩典、女性性或單一形上原理；補出通往 CORE 06、07 的章序。 | 正文：小幅連續性修訂。Evidence：未改。 | `Das Ewig-Weibliche` 固定「永恆女性」，並保留抽象性、多義與競爭性性別閱讀。 | Mahler 1909 年書信仍是事後解讀；完整 genealogy 待原始書信版與 Hefling。 |
| CORE 06 | 與 CORE 01 競爭同一網絡史；舊章題與「形成能力」措辭可能超出脈絡證據。 | 章題改為「青年網絡提供了什麼脈絡」；結尾把可得性／問題環境與 Mahler 內在能力、作品因果分開；明確交棒給 CORE 07 的讚歌文本。 | 正文：小幅證據安全與章界修訂。Evidence：未改。 | `閱讀與友誼網絡`、`政治共同體`、`文化共同體` 分用；`影響` 只在傳播與作用可證時使用。 | McGrath、Kita、Hefling、Batstone 2023 與青年日記／完整書信仍缺；Lipiner 只能是待查可能。 |
| CORE 07 | 必須完整教讚歌，同時不預做 CORE 08；術語需與全書一致。 | 章職與內容原樣保留；只統一讚歌名稱、`caritas`／`amor` 區分與「祈禱共同體」限定。 | 正文：術語微調。Evidence：同幅術語微調，未改 claim type、來源、信心或限制。 | 首次固定「來吧，創造者聖靈（*Veni Creator Spiritus*）」；`Spiritus` 譯聖靈；`caritas` 譯基督宗教的愛／仁愛；`照明` 指獲得感知與理解能力。 | 完整 hymn critical apparatus、chant history 與 Mahler critical score 仍缺。 |
| CORE 08 | 重教 CORE 07；未充分繼承 CORE 05 的多義；需把成品整合與初始形成史變成全章中軸。 | 重新組織為：三種「放在一起」→保留詞義差異→呼求／被接引的回應→具名音樂關係→整合不等於同時起源→競爭性整體模型。刪除從作者、禮儀用途與逐項祈求重開的課程；新增永恆女性的反等同限制及 Evidence 對應。 | 正文：實質重構。Evidence：更新導言並新增三列，分別記錄永恆女性多義、三種證據問題、Bauer／Adorno 競爭性評價；既有來源與信心限制保留。 | `finished-work integration` 固定譯「完成作品中的整合」；`initial compositional genesis` 固定譯「最初形成史／初始作曲形成」；相似、回應、音樂回返均不升格為初始同時構思。 | 缺總譜／校勘報告、autograph sketches 與完整 Mahler 書信版；精確形成次序及逐小節動機圖延後。CORE 09–10 須接續公共演出、代表／排除與接受問題。 |

## 主要重複移除

- CORE 01 不再承擔 Pernerstorfer 圈的具名人物史、Lipiner 1878 講題與精確分流；這些只在 CORE 06 完整教授。
- CORE 05 以回指取代重講 Gretchen 悲劇與救贖機制；完整故事在 CORE 03，機制在 CORE 04。
- CORE 08 不再重教讚歌作者、禮儀用途、逐項祈求或 Mahler 文字重排的基礎課；這些只在 CORE 07 完整教授。

## 最終順讀結果

| 章 | 唯一主要認知任務 |
|---|---|
| CORE 01 | 建立多重衝突共存的 Vienna 歷史地圖。 |
| CORE 02 | 說明 Goethe／Faust 為何成為可爭論、可改寫的文化權威。 |
| CORE 03 | 建立兩部《浮士德》的可運作故事地圖與責任鏈。 |
| CORE 04 | 拆解 Faust 得救的機制，保存責任、恩典、代求與轉化的差別。 |
| CORE 05 | 細讀永恆女性的語法、角色分立與競爭性解釋。 |
| CORE 06 | 重建 Mahler 青年閱讀／友誼網絡，限定它只能證明脈絡與文件化關係。 |
| CORE 07 | 教授聖靈讚歌的身分、祈求、核心詞義與 Mahler 的文字重排。 |
| CORE 08 | 解釋兩部如何在完成作品中整合，同時保留詞義差異與形成史空白。 |

順讀確認：知識由歷史條件累積至文化權威、故事、救贖、多義終句、思想脈絡、讚歌文本與成品整合；沒有章節重新從零開始。CORE 01／06、CORE 03／04／05、CORE 07／08 的分工現已清楚。所有因果限制、具名詮釋歸屬、二手轉述與缺來源警告均保留；沒有為連續性而把任一章改淺。

## 未解但不阻擋交接

- CORE 08 的音樂關係仍依 Papanikolaou 與 Bauer 等具名研究，不能假裝已由本書獨立核對完整總譜。
- Mahler 是否從第一刻同時計畫兩部仍未證；finished-work integration 不回答 initial genesis。
- Lipiner／Justine Mahler／Faust 到《第八號》的傳播鏈、Mahler 1909 書信原文版、Goethe 現代批判版及完整讚歌文本學仍待補。
- CORE 09–10 必須繼承「共同體」的功能限定，並處理巨大公共演出如何召集、代表或排除不同群體。
- Final Editorial 仍需完成全書人物索引／概念索引、標題格式、原文斜體、中文譯名與跨章連結的出版層統一。

## 交接判定

CORE 01–08 已適合作為 CORE 09–10 的 continuity inputs。此判定表示章序、術語與證據邊界已足以安全續寫，不表示上述來源缺口已被填補，也不表示 CORE 01–10 已完成最終出版編輯。

==================================================
ORIGINAL FILE: TERMINOLOGY_DECISIONS_01_08.md
==================================================

# CORE 01–08｜術語決策

狀態：供 CORE 09–10 強制繼承；尚非最終全書 style sheet。

原則：不為文采輪替近義詞。若不同語言或文本使用不同詞，即使中文可譯得相近，也須保留來源語境與功能差別。

| 原詞／概念 | CORE 01–08 固定用法 | 必須保留的差別 |
|---|---|---|
| *Streben* | 首次寫「*Streben*（持續追求）」；後文依句法用「追求」。 | 是活動形式，不是道德善、功績或自救保證；方向、手段、關係與後果仍受評價。 |
| salvation / redemption | `救贖` 指結構、過程或題旨；`得救` 指角色被拯救的事件／狀態；引文 *erlösen* 依句法譯「拯救」。 | 得救不等於從未有罪；救贖不取消責任；被接引不等於轉化完成。 |
| *Gnade*／*gratia* | 中文均用「恩典」；關鍵比較保留德文／拉丁文。 | 同一中文不表示 Goethe 終場與拉丁讚歌屬同一神學系統；恩典不是努力的報酬。 |
| *Liebe* | 依上下文用「愛」；*Liebe von oben* 固定「從上而來的愛」。 | 不與 Gretchen 的戀愛、*caritas*、*Eros* 或恩典自動等同。 |
| *caritas* | 「基督宗教的愛／仁愛（*caritas*）」。 | 屬讚歌的聖靈／神聖之愛語境，不與浪漫愛情、一般 *amor*、*Eros* 或創意互換。 |
| *amor* | 「愛（*amor*）」；必要時保留拉丁文。 | 與同節 *caritas* 相關但不是為中文流暢而合併的同一詞。 |
| *Eros* | 「愛欲（*Eros*）」；只在來源或具名詮釋實際使用時出現。 | 不回投成 Goethe 或 Mahler 1906 年已文件化的概念，也不與 *caritas* 互換。 |
| *Spiritus*／Holy Spirit | 讚歌稱謂固定「聖靈」；不採「聖神」章間輪換。 | 不泛化成「精神」；歷史祈禱對象不能被藝術創造隱喻取代。 |
| *Creator Spiritus* | 固定「創造者聖靈」；全名首次寫「來吧，創造者聖靈（*Veni Creator Spiritus*）」，後文可稱「聖靈讚歌」。 | 「創造者」首先指聖靈創造／更新；藝術創造是第二層詮釋橋樑。 |
| *Geist* | 依 Goethe 德文語境譯「精神／靈／心靈」，必要時保留原文。 | 不因英文皆可作 *spirit* 就等同 *Spiritus* 或 Holy Spirit。 |
| intercession | 固定「代求」。 | 是為他者發聲並向更高者請求；不等同戀愛、恩典或直接救贖。 |
| illumination | 固定「照明」；首次或易誤解處說明為獲得感知、看見與理解的能力。 | 不是舞台燈光，也不與恩典、愛或轉化互換。 |
| transformation | 固定「轉化」。 | 指尚在進行的改變，不是瞬間無罪化或得救的同義詞。 |
| ascent | 固定「上升」。 | 保留過程性與關係性，不自動等同救贖已完成。 |
| *Das Ewig-Weibliche* | 固定「永恆女性（*Das Ewig-Weibliche*）」；必要時解釋為抽象的「永恆的女性性」。 | 不是所有女人、Gretchen、Mater Gloriosa、愛、恩典、母性、美、Jung 的 *anima* 或單一形上原理。跨部只使用牽引／上升等可證功能。 |
| *Mater Gloriosa* | 固定「榮耀之母（*Mater Gloriosa*）」。 | 不與 Gretchen、永恆女性或 *Mater Dolorosa* 混同；後者只用於第一部悲苦聖母祈禱的明確場景。 |
| influence | 固定「影響」。 | 只在接觸／傳播及作用均有證據時使用；共同閱讀、可得性或相似不能升格為影響。 |
| context | 固定「脈絡」。 | 表示歷史可得性、問題環境或理解條件；不證明創作因果。 |
| documented connection | 固定「文件化關係／有文件支持的連結」。 | 比脈絡強，但仍須說明文件證明的是友誼、閱讀、言論或何種具體關係。 |
| reception / reception history | 固定「接受／接受史」。 | 指後人如何閱讀、改寫、演出或使用作品；不等於原作者意圖。 |
| interpretation | 固定「詮釋」。 | 爭議性主張須具名歸屬；後來詮釋不得回投成 Mahler 或 Goethe 的已證思想。 |
| similarity / response | 「相似」「對照」「回應」依實際關係使用。 | 主題或語義可比較不等於因果，也不建立一對一象徵等號。 |
| finished-work integration | 固定「完成作品中的整合」，首次可附英文。 | 回答成品如何組織、回返與要求跨部記憶。 |
| initial compositional genesis | 固定「最初形成史」或在技術語境寫「初始作曲形成」，首次可附英文。 | 回答兩部在何時進入構想；不能由成品整合倒推同時起源。 |
| community | 不單獨泛稱；依章職寫「政治共同體」「文化共同體」「閱讀與友誼網絡」「祈禱共同體」「表演與聆聽共同體」。 | 不把民族政治、朋友圈、禮儀會眾、演出群體與抽象人類合併。 |

## CORE 09–10 必須延續的證據句法

- `影響` 需要傳播、接觸與作用證據；否則寫 `脈絡`、`可得性`、`可比較` 或具名 `詮釋`。
- 完成作品中的主題回返可以支持整合，不得寫成最初已同時計畫的證明。
- Mahler 作品完成後的書信與回憶可證後來理解／自我敘述，不得自動回投至 1906 年最初構想。
- 同一中文譯詞不能消除拉丁讚歌、Goethe 劇本、Mahler 言論與後來研究之間的來源差異。
- 學者觀點若只是兩種可用模型，寫「兩種具名讀法」，不得寫成「學界兩派」或完整共識。


==================================================
ORIGINAL FILE: CROSS_CHAPTER_REVISION_NOTES_09_10.md
==================================================

# CORE 09–10｜跨章修訂備忘

狀態：供 Final Editorial 使用。依任務限制，未直接改寫 CORE 01–08。

| 受影響章節 | 類別 | 精確問題 | 為何重要 | 最小未來修訂方向 |
|---|---|---|---|---|
| CORE 01 → CORE 09 | CONTINUITY | CORE 01 結尾已指出公共藝術可承載共同體理想與排除機制；CORE 09 必須承接但不能重教 Vienna 政治。 | 若 CORE 09 重述 Ringstraße／mass politics，會削弱其「尺度如何成為公共主張」的新認知任務。 | Final Editorial 只需加一個跨章連結，指向 CORE 01 的多重衝突與 CORE 09 的表演／聆聽共同體；正文內容不需重寫。 |
| CORE 06 → CORE 09–10 | TERMINOLOGY | `共同體` 已分成閱讀與友誼網絡、政治共同體、文化共同體；CORE 09 新增「表演與聆聽共同體」。 | 若都簡寫成「共同體」，容易把朋友圈、政治民族、祈禱會眾與演出群體誤認為同一歷史主體。 | 在全書 terminology/style sheet 納入新詞，並於概念索引建立各用法的互連。 |
| CORE 07–08 → CORE 10 | DUPLICATION | CORE 10 必須使用祈禱／整合知識，但若再列舉所有 petitions 或跨部音樂回返，會重教 CORE 07–08。 | 最終章應比較分類框架，而不是重寫文本整合章。 | 現稿已採最低提醒；Final Editorial 應保留此章界，只用內部連結帶回 CORE 07／08。 |
| CORE 08 → CORE 09 | STRUCTURE | CORE 08 末句已預告公共演出會「召集、代表或排除誰」；CORE 09 實際只能可靠處理作品形成的公共主張與後來接受，無 1910 audience dossier。 | 預告若讀成即將提供實證首演社會史，會高估 CORE 09 的證據能力。 | Final Editorial 可把 CORE 08 最後一句微調為「這種巨大公共形式如何提出共同體主張，又會引發代表／排除問題」，避免承諾未具資料的首演人口史。 |
| CORE 08 → CORE 10 | TERMINOLOGY | `Mass`／religious drama／symphony 等已在 CORE 08 末段出現，但 CORE 10 才負責系統比較分類框架。 | CORE 08 若類型清單過度展開，會提前消耗 CORE 10。 | Final Editorial 可保留 CORE 08 的最低類型越界提示，把各標籤的解釋力／盲點明確留給 CORE 10。 |
| CORE 09–10 → 全書 | EVIDENCE | CORE 09–10 的首演史、精確編制、Adorno 原文與系統性接受史仍不足。 | 終章最容易因修辭收束而把 conditional interpretation 寫成整體史實。 | Final Editorial 不應刪除 evidence limitations；若未補來源，仍維持「公共形式」而非「1910 公眾共同理解」、Arbo 二手而非 Adorno 原文的表述。 |
| CORE 10 → CORE 01–09 | STRUCTURE | CORE 10 使用「帶限制條件的答案」收束全書，不逐章摘要。 | 若出版編輯另加冗長回顧，會破壞 culminative 而非 recap 的任務。 | 只建立章間超連結或側欄索引，不在 CORE 10 正文插入九章摘要。 |
| CORE 05／08／10 | CONTINUITY | 永恆女性在 CORE 10 只作結尾來源的一部分，未再呈現 Niekerk／Trop／Mahler 1909 的完整競爭性解讀。 | 這是有意依賴 CORE 05，不是缺漏；後續編輯可能誤以為終章必須重講。 | 保留現有最低提醒並以連結回 CORE 05；不可在 CORE 10 把永恆女性簡化成「愛」或「人文價值」。 |

## 不需回修的確認

- CORE 03–05 已完整建立 Faust 的責任、得救、代求、教導、上升與永恆女性歧義；CORE 10 依賴這些知識即可。
- CORE 07–08 已清楚區分 *Spiritus*／*Geist*、*caritas*／*Liebe*／*Eros*、完成作品整合／最初形成史；CORE 09–10 未改動上述結論。
- CORE 09 新增的公共尺度問題與 CORE 10 的 competing-framework synthesis 具有獨立認知任務，未發現需要直接改寫 CORE 01–08 的矛盾。

==================================================
ORIGINAL FILE: TERMINOLOGY_DECISIONS_09_10.md
==================================================

# CORE 09–10｜術語決策

狀態：供後續 Final Editorial 繼承。僅記錄會影響全書的新增決定，不建立大型 glossary。

| 原詞／概念 | CORE 09–10 固定用法 | 必須保留的差別 |
|---|---|---|
| monumentality | 首次寫「monumentality（紀念碑式宏偉／巨型尺度）」；後文依句法用「宏偉」「巨大尺度」或保留原文。 | 指尺度產生的文化、審美與權威效果，不是 performer count 的同義詞；不自動褒義或貶義，也不直接證成政治意圖。 |
| public | 依功能寫「公共形式」「公共藝術作品」「公共主張」「公共經驗」。 | `public` 不自動等於 1910 實際 audience、民族或全民共識；後者需首演／接受史證據。 |
| collective | 固定「集體」；若指演出關係，優先寫「集體發聲」。 | 不與 `public` 或 `universal` 互換；多人發聲不證明所有人被代表。 |
| universal / universality | 寫「普世／普世性」，並盡量標明是「藝術主張」「權威效果」或具名詮釋。 | 不寫成作品已實現的政治包容，也不由巨大規模直接推導。 |
| performance-and-listening community | 固定「表演與聆聽共同體」。 | 與政治共同體、文化共同體、閱讀與友誼網絡、祈禱共同體分開；指演出中由身體、分工與共享注意力暫時形成的群體。 |
| genre crossing | 固定「類型越界」。 | 表示作品同時調動多種類型記憶，不表示已無類型，也不要求選出唯一名稱。 |
| symphonic Mass | 固定「交響彌撒（*symphonic Mass*）」並明標為十九世紀類型史／分析框架。 | 不因此把《馬勒第八號》客觀分類為 Mass；Mahler「我的彌撒」是 Roller 轉述的後來自我描述。 |
| Gesamtkunstwerk | 固定「總體藝術作品（*Gesamtkunstwerk*）」。 | 只在有證據的類型／文化討論中使用；不建立 Wagner 或 Reinhardt 對《第八號》的文件化影響。 |
| Mysterium / mystery | 依語境寫「神秘劇／奧祕式戲劇（*Mysterium*）」；Devutsky 的 `symphony-mystery` 寫「交響—神秘劇」。 | `mystery` 不是「尚待破解的祕密」；Devutsky 模型不等於 Mahler programme，也不與 Christian sacrament 自動等同。 |
| sacred / religious | `sacred` 依語境譯「神聖／宗教性」；`religious work` 寫「宗教作品」或「具有宗教內容的作品」。 | 不與 `liturgical`（禮儀性／用於禮儀）互換；音樂會作品可保留宗教內容而非正式禮儀。 |
| humanist | 固定「人文主義的／人文取向」並標示為分析框架。 | 不表示無宗教、反宗教或「人類自救」；不能取代 *Spiritus*、恩典與祈禱的歷史身分。 |
| metaphysical | 固定「形上的／形上計畫」。 | 指創造來源、整體、死亡、轉化等問題；不可用抽象詞抹去具體角色、歷史與權力關係。 |
| utopia / utopian impulse | `utopia` 依語境用「烏托邦」；`utopian impulse` 固定「烏托邦衝動」。 | 不等於可執行的理想社會藍圖或已完成和解；Papanikolaou／Bloch／Adorno 脈絡須分別歸屬。 |
| affirmation | 固定「肯定」。 | 先問肯定的對象；聲響肯定不等於倫理、歷史與政治矛盾皆已解決，也不等於作品必然真誠。 |
| counter-reading | 固定「反讀／反向閱讀」，依句法使用。 | 後來批評用來測試作品的盲點，不是 Mahler 的原始 programme，也不是為形式平衡而加入的假反方。 |
| later reception | 沿用「後來接受／接受史」。 | Barham／Fassbinder 材料只證明後來再語境化；不得回投至 1906 genesis 或 1910 audience。 |
| temporary enactment | CORE 10 的書內綜合採「暫時成形／暫時實行」。 | 指藝術能在演出時間內使可能世界可被共同經驗；不是說作品虛假，也不表示歷史和解已完成。 |

## 繼承確認

- 沿用 CORE 01–08 的 *Streben*、救贖／得救、恩典、*Liebe*、*caritas*、*Eros*、*Spiritus*／*Geist*、代求、照明、轉化、上升與永恆女性等決定。
- 沿用 `finished-work integration`＝「完成作品中的整合」、`initial compositional genesis`＝「最初形成史／初始作曲形成」的區分。
- `interpretation`、`context`、`documented connection`、`reception` 仍保持不同證據層級，不因終章需要收束而加強句法。

==================================================
ORIGINAL FILE: GEMINI_ADJUDICATION_09_10.md
==================================================

# CORE 09–10｜Gemini 審查正典裁決

狀態：POST-REVIEW CANONICAL ADJUDICATION  
審查輸入：`GEMINI_REVIEW_CORE_09_10.md`  
權限：Gemini 為 independent reviewer／red-team；本檔記錄 canonical GPT Work 的逐項裁決。

## 裁決統計

| Decision | Count |
|---|---:|
| ACCEPT | 1 |
| PARTIALLY ACCEPT | 2 |
| REJECT | 0 |

## Issue 1

- **Chapter:** CROSS-CHAPTER／CORE 09–10
- **Gemini diagnosis:** 兩章過度依賴「不是 A，而是 B」及相近的二元否定句型，造成可預測、說教式的節奏，並可能使作者聲音偏離 CORE 01–08。
- **Decision:** **PARTIALLY ACCEPT**
- **Reason:** 診斷指出了真實的句法密度問題；多個段落確實先搭建假想錯誤，再進入主張，使閱讀節奏單一。然而 Gemini 將問題定為全面性的 `MAJOR` 略嫌過度。部分否定／對比句承擔必要工作，例如區分 interpretation 與 programme、reception 與 original intention、公共主張與實際代表性。機械移除會削弱本書最重要的證據與概念界線。
- **Canonical revision made:** CORE 09、CORE 10 多數段落主幹已改為直接肯定句；章首、部分小標、類型說明、公共性、烏托邦、人文／形上、Adorno 反讀、接受史與兩章結尾均重新安排句法。保留的否定句限於實質區分，不把個別短語列為禁用格式。
- **Evidence consequence:** 無 claim-level 變更；未新增、刪除或加強任何事實與因果主張。`CORE_09_EVIDENCE.md`、`CORE_10_EVIDENCE.md` 無須修改。

## Issue 2

- **Chapter:** CORE 10
- **Gemini diagnosis:** 宗教作品小節再次逐項列出 *Veni Creator Spiritus* 的探訪、恩典、照明、愛、力量、和平與信仰，重複 CORE 07 及 CORE 09 已教內容。
- **Decision:** **ACCEPT**
- **Reason:** 這是結論章中的真實重複。CORE 10 的認知任務是比較框架，只需守住聖靈讚歌的歷史與宗教身分，無須再教完整 petition list。
- **Canonical revision made:** 改為「*Veni Creator Spiritus* 保留其向創造者聖靈呼求的歷史與宗教身分」，並直接銜接第二部的基督宗教圖像。宗教身分與 `Spiritus` 的詞義邊界均保留。
- **Evidence consequence:** 刪除的是 public-prose 細節重述，沒有撤銷底層證據。CORE 10 Evidence 中關於讚歌內容的繼承列仍作內部查核用途，故不修改。

## Issue 3

- **Chapter:** CROSS-CHAPTER／CORE 09、CORE 10
- **Gemini diagnosis:** 「目前材料足以／不足以」「現有材料沒有」等專案層級 meta-commentary 打斷教科書敘事；應改成客觀的學術限制。
- **Decision:** **PARTIALLY ACCEPT**
- **Reason:** 讀者不需要知道作者的檔案庫狀態，原句確有專案免責聲明的口吻。但 Gemini 對 CORE 10 提議「不必重建 Adorno 每一項論證」仍可能淡化真正的來源位置：本章實際透過 Arbo 的二手研究援引 Adorno，不能讓讀者誤以為作者直接掌握完整 Adorno 原文。CORE 09 的首演史邊界也必須留在 public prose，否則「公共」容易被誤讀為 1910 audience history。
- **Canonical revision made:** CORE 09 改為客觀界定章節範圍，並說明精確首演人數、舞台、宣傳與觀眾反應需要首演檔案另行支撐。CORE 10 改為直接交代 Adorno 的援引經由 Arbo 二手研究，只抽取一項可明確歸屬的反讀原則，不延伸成對《第八號》的完整判決。
- **Evidence consequence:** 證據限制由 project-state wording 改成 source-position wording；限制本身沒有減弱。兩份 Evidence ledgers 已完整記錄首演檔案與 Adorno 原文缺口，無須修改。

## Canonical outcome

- CORE 09 仍以巨大公共尺度、集體發聲、權威、普世主張與後來接受為獨立認知任務。
- CORE 10 仍比較 competing frameworks，沒有退化為章節摘要或「Mahler 結合一切」的空泛結論。
- CORE 09 → CORE 10 的推進維持為「尺度如何運作」→「這究竟是一部什麼作品」。
- FACT、DOCUMENTED CONNECTION、CONTEXT、INTERPRETATION、RECEPTION 的層級均未被加強或混用。
- `CROSS_CHAPTER_REVISION_NOTES_09_10.md` 與 `TERMINOLOGY_DECISIONS_09_10.md` 的既有決策仍有效；本輪沒有產生新的術語衝突。
