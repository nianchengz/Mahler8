# CORE 09–10｜跨章修訂備忘

狀態：供 Final Editorial 使用。依任務限制，未直接改寫 CORE 01–08。

| 受影響章節 | 類別 | 精確問題 | 為何重要 | 最小未來修訂方向 |
|---|---|---|---|---|
| CORE 01 → CORE 09 | CONTINUITY | CORE 01 結尾已指出公共藝術可承載共同體理想與排除機制；CORE 09 必須承接但不能重教 Vienna 政治。 | 若 CORE 09 重述 Ringstraße／mass politics，會削弱其「尺度如何成為公共主張」的新認知任務。 | Final Editorial 只需加一個跨章連結，指向 CORE 01 的多重衝突與 CORE 09 的表演／聆聽共同體；正文內容不需重寫。 |
| CORE 06 → CORE 09–10 | TERMINOLOGY | `共同體` 已分成閱讀與友誼網絡、政治共同體、文化共同體；CORE 09 新增「表演與聆聽共同體」。 | 若都簡寫成「共同體」，容易把朋友圈、政治民族、祈禱會眾與演出群體誤認為同一歷史主體。 | 在全書 terminology/style sheet 納入新詞，並於概念索引建立各用法的互連。 |
| CORE 07–08 → CORE 10 | DUPLICATION | CORE 10 必須使用祈禱／整合知識，但若再列舉所有 petitions 或跨部音樂回返，會重教 CORE 07–08。 | 最終章應比較分類框架，而不是重寫文本整合章。 | 現稿已採最低提醒；Final Editorial 應保留此章界，只用內部連結帶回 CORE 07／08。 |
| CORE 08 → CORE 09 | STRUCTURE | CORE 08 末句已預告公共演出會「召集、代表或排除誰」；CORE 09 實際只能可靠處理作品形成的公共主張與後來接受，無 1910 audience dossier。 | 預告若讀成即將提供實證首演社會史，會高估 CORE 09 的證據能力。 | Final Editorial 可把 CORE 08 最後一句微調為「這種巨大公共形式如何提出共同體主張，又會引發代表／排除問題」，避免承諾未具資料的首演人口史。 |
| CORE 08 → CORE 10 | TERMINOLOGY | `Mass`／religious drama／symphony 等已在 CORE 08 末段出現，但 CORE 10 才負責系統比較分類框架。 | CORE 08 若類型清單過度展開，會提前消耗 CORE 10。 | Final Editorial 可保留 CORE 08 的最低類型越界提示，把各標籤的解釋力／盲點明確留給 CORE 10。 |
| CORE 09–10 → 全書 | EVIDENCE | CORE 09–10 的首演史、精確編制、Adorno 原文與系統性接受史仍不足。 | 終章最容易因修辭收束而把 conditional interpretation 寫成整體史實。 | Final Editorial 不應刪除 evidence limitations；若未補來源，仍維持「公共形式」而非「1910 公眾共同理解」、Arbo 二手而非 Adorno 原文的表述。 |
| CORE 10 → CORE 01–09 | STRUCTURE | CORE 10 使用「帶限制條件的答案」收束全書，不逐章摘要。 | 若出版編輯另加冗長回顧，會破壞 culminative 而非 recap 的任務。 | 只建立章間超連結或側欄索引，不在 CORE 10 正文插入九章摘要。 |
| CORE 05／08／10 | CONTINUITY | 永恆女性在 CORE 10 只作結尾來源的一部分，未再呈現 Niekerk／Trop／Mahler 1909 的完整競爭性解讀。 | 這是有意依賴 CORE 05，不是缺漏；後續編輯可能誤以為終章必須重講。 | 保留現有最低提醒並以連結回 CORE 05；不可在 CORE 10 把永恆女性簡化成「愛」或「人文價值」。 |

## 不需回修的確認

- CORE 03–05 已完整建立 Faust 的責任、得救、代求、教導、上升與永恆女性歧義；CORE 10 依賴這些知識即可。
- CORE 07–08 已清楚區分 *Spiritus*／*Geist*、*caritas*／*Liebe*／*Eros*、完成作品整合／最初形成史；CORE 09–10 未改動上述結論。
- CORE 09 新增的公共尺度問題與 CORE 10 的 competing-framework synthesis 具有獨立認知任務，未發現需要直接改寫 CORE 01–08 的矛盾。
