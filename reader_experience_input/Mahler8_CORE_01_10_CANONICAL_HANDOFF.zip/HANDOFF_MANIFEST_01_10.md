# Mahler VIII｜CORE 01–10 Canonical Handoff Manifest

建立日期：2026-09-02  
Package：`Mahler8_CORE_01_10_CANONICAL_HANDOFF.zip`  
用途：下一階段 Reader Experience／pedagogical readability 編輯的 canonical base。

## Canonical status

- CORE 01–08 是目前的 continuity-canonical versions。
- CORE 09–10 是目前完成 Gemini review 與 canonical GPT Work adjudication 後的 post-review canonical versions。
- 本次作業只進行機械合併與封裝；沒有修訂任何章文、Evidence statement、術語決策或既有編輯紀錄。

## Five compact handoff files

1. `CORE_01_10_CANONICAL_TEXT.md`  
   完整收錄 CORE 01–10 當前 public prose；十章皆以 `ORIGINAL FILE` 邊界分隔。

2. `CORE_01_10_EVIDENCE.md`  
   完整收錄 CORE 01–10 當前 Evidence；保留所有 Source ID、頁碼／段落位置、Evidence type、confidence、qualification 與 limitation。

3. `CORE_01_10_CONTINUITY_AND_TERMINOLOGY.md`  
   完整收錄 CORE 01–08 continuity audit、CORE 01–08 terminology decisions、`CROSS_CHAPTER_REVISION_NOTES_09_10.md`、`TERMINOLOGY_DECISIONS_09_10.md` 與 `GEMINI_ADJUDICATION_09_10.md`。

4. `CORE_01_10_CONTROL.md`  
   收錄當前 governing Editorial Charter 與 ten-chapter architecture，並明示舊 500–800 字短章規則已失效；現行深度由最新 Editorial Charter 管轄。

5. `HANDOFF_MANIFEST_01_10.md`  
   本檔；界定檔案角色、權威狀態、下階段權限與版本安全。

## Next-stage authority

- 這五檔是下一階段 Reader Experience／pedagogical readability 編輯的 canonical base。
- 下一位編輯可以大幅改善呈現方式，包括重新排序、改寫、補充導航與增加具有 Evidence 支持的內容。
- 下一位編輯必須維持 Evidence discipline；不得默默創造事實材料，也不得把 CONTEXT、INTERPRETATION、RECEPTION 或相似性加強為 FACT、DOCUMENTED CONNECTION、原始意圖或因果。
- 任何後續新增的 substantive factual material 都必須取得相應 Evidence 支持。

## Archival safety files included

- 當前 CORE 09–10 個別 Draft + Evidence 四檔。
- 當前 CORE 01–08 五份 handoff 檔：canonical aggregate、Evidence aggregate、continuity／terminology、control、manifest。
- CORE 09–10 的 cross-chapter notes、terminology decisions 與 Gemini adjudication。
- `HANDOFF_SHA256_01_10.txt` 完整性校驗檔。

## Version safety

- 不含 superseded Draft、pre-adjudication CORE 09–10 prose、Gemini-direct alternate prose 或 provisional target。
- `CORE_01_10_CANONICAL_TEXT.md` 的 CORE 01–08 部分逐位元繼承現有 continuity-canonical aggregate，CORE 09–10 部分逐位元繼承 post-adjudication Draft。
- `CORE_01_10_EVIDENCE.md` 的 CORE 01–08 部分逐位元繼承現有 Evidence aggregate，CORE 09–10 部分逐位元繼承當前 Evidence。
