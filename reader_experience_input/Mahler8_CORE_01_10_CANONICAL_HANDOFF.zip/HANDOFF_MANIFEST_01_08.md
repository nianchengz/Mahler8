# Mahler VIII｜CORE 01–08 Canonical Handoff Manifest

## Status and authority

- This package contains the current continuity-canonical CORE 01–08.
- CORE 01–08 have completed their earlier batch reviews and canonical Work adjudications, followed by the full CORE 01–08 continuity pass.
- The sixteen individual `CORE_01`–`CORE_08` Draft／Evidence files are the authoritative chapter-level archive.
- The aggregate files reproduce those authoritative files only for browser-upload convenience. They are not independent alternate versions.
- CORE 09–10 must treat CORE 01–08 as its established continuity base and must not rewrite CORE 01–08.
- If CORE 09–10 reveals a possible issue in CORE 01–08, record it for later Final Editorial rather than silently changing an established chapter.
- Evidence qualifications, confidence limits and distinctions among FACT, DOCUMENTED CONNECTION, CONTEXT and INTERPRETATION must not be strengthened.
- Decisions in `TERMINOLOGY_DECISIONS_01_08.md` must be inherited unless CORE 09–10 reveals a genuine conceptual conflict. Any such conflict must be documented rather than silently normalized.

## Authoritative individual archive

- `CORE_01_DRAFT.md`／`CORE_01_EVIDENCE.md`
- `CORE_02_DRAFT.md`／`CORE_02_EVIDENCE.md`
- `CORE_03_DRAFT.md`／`CORE_03_EVIDENCE.md`
- `CORE_04_DRAFT.md`／`CORE_04_EVIDENCE.md`
- `CORE_05_DRAFT.md`／`CORE_05_EVIDENCE.md`
- `CORE_06_DRAFT.md`／`CORE_06_EVIDENCE.md`
- `CORE_07_DRAFT.md`／`CORE_07_EVIDENCE.md`
- `CORE_08_DRAFT.md`／`CORE_08_EVIDENCE.md`

## Continuity and control records

- `CORE_01_08_CONTINUITY_AUDIT.md`
- `TERMINOLOGY_DECISIONS_01_08.md`
- `EDITORIAL_CHARTER.md`
- `CORE_10_CHAPTERS.md`

The old 500–800-character short-guide standard is obsolete. The current Editorial Charter and its approximately 2,000–4,000-character substantive teaching-depth standard control.

## Recommended five-file upload set for the new CORE 09–10 Project

1. `CORE_01_08_CANONICAL_AGGREGATE.md`
2. `CORE_01_08_EVIDENCE_AGGREGATE.md`
3. `CORE_01_08_CONTINUITY_AND_TERMINOLOGY.md`
4. `CORE_01_08_CONTROL.md`
5. `HANDOFF_MANIFEST_01_08.md`

These compact files are handoff reproductions and control aids. When any apparent discrepancy is found, the individual canonical Draft／Evidence files and the current control records govern.
